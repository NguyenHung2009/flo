static bool MenDeal = false;
static bool StreamerMode = false;

// Animation properties
const float kAnimationDuration = 0.5f;

// Lerp function for smooth animation
static inline CGFloat Lerp(CGFloat a, CGFloat b, CGFloat t) {
    return a + t * (b - a);
}



- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();
    AddTexturesFromImageData(_device);
    id<MTLTexture> texture = nil;
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, _Airi_data, sizeof(_Airi_data));
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider(dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:self.device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
        NSLog(@"Failed to load texture: %@", error.localizedDescription);
    }
    [self updateSwitchStates];
    [self checkversion];
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();

    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;

    static const ImWchar icons_ranges[] = {0xf000, 0xf3ff, 0};

    NSString *fontPath = nssoxorany("/System/Library/Fonts/Core/SFUIMono.ttf");

    _espFont = io.Fonts->AddFontFromFileTTF(fontPath.UTF8String, 30.f, &config, io.Fonts->GetGlyphRangesVietnamese());
    io.FontGlobalScale = 0.35f;

    ImGui_ImplMetal_Init(_device);
    NSString *fileName = @"IMG_2490.gif";
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:fileName];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        NSData *fileData = [NSData dataWithContentsOfFile:filePath];
        [self displayGIFWithUIImageView:fileData];
    } else {
        NSString *urlString = nssoxorany("https://raw.githubusercontent.com/cbeios/Mod/refs/heads/main/IMG_2490.gif");
        NSURL *url = [NSURL URLWithString:urlString];

        NSURLSessionDataTask *downloadTask = [[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error) {
            if (data && !error) {
                [data writeToFile:filePath atomically:YES];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self displayGIFWithUIImageView:data];
                });
            } else {
                NSLog(@"Lỗi khi tải file: %@", error.localizedDescription);
            }
        }];
        [downloadTask resume];
    }
    return self;
}

- (void)displayGIFWithUIImageView:(NSData *)gifData {
    CGImageSourceRef source = CGImageSourceCreateWithData((CFDataRef)gifData, NULL);
    size_t count = CGImageSourceGetCount(source);
    NSMutableArray *frames = [NSMutableArray array];

    for (size_t i = 0; i < count; i++) {
        CGImageRef imageRef = CGImageSourceCreateImageAtIndex(source, i, NULL);
        UIImage *frame = [UIImage imageWithCGImage:imageRef];
        [frames addObject:frame];
        CGImageRelease(imageRef);
    }
    CFRelease(source);
    GifView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 56)];
    GifView.animationImages = frames;
    GifView.animationDuration = 4.0;
    GifView.contentMode = UIViewContentModeScaleAspectFit;
    [GifView startAnimating];
}

- (void)drawInMTKView:(MTKView *)view {
    hideRecordTextfield.secureTextEntry = boolUS[12];

    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 120);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    [self.view setUserInteractionEnabled:MenDeal];
    [self.view.superview setUserInteractionEnabled:MenDeal];
    [menuTouchView setUserInteractionEnabled:MenDeal];

    MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) {
        id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:nssoxorany("Crack cbe")];
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        CGFloat width = kWidth;
        CGFloat height = kHeight;
        ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);

        if (MenDeal == true) {
            // char* Gnam = (char*) [[NSString stringWithFormat:nssoxorany("Free Fire - Version: %@ "), ver] cStringUsingEncoding:NSUTF8StringEncoding];
            if (!isMenuVisible) {
                isMenuVisible = true;
                [self Menucuatoi];
                updateTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateLabels) userInfo:nil repeats:YES];
            }
        } else {
            [self closeMenu];
        }
        cheatHandle();
        if (boolUS[2]) {
            if (!boolUS[15]) {
                self.mtkView.preferredFramesPerSecond = 60;
            } else {
                self.mtkView.preferredFramesPerSecond = (int)round([[NSUserDefaults standardUserDefaults] floatForKey:@"Slider2"]);
            }
        } else {
            self.mtkView.preferredFramesPerSecond = 120;
        }

        
        ImDrawList *draw_list = ImGui::GetBackgroundDrawList();
        DrawOverlay(draw_list);
        ImGui::Render();
        ImDrawData *draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];

        [commandBuffer presentDrawable:view.currentDrawable];
    }
    [commandBuffer commit];
}

- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size {
}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

+ (void)showChange:(BOOL)open {
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

+ (void)addWindow:(UIWindow *)window {
    mainWindow1 = window;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

- (void)loadView {
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.mtkView.device = self.device;
    if (!self.mtkView.device) {
        return;
    }
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    self.mtkView.preferredFramesPerSecond = 60;
}

- (void)checkversion {
    ver = [[[NSBundle mainBundle] infoDictionary] objectForKey:nssoxorany("CFBundleShortVersionString")];
    bundle = [[NSBundle mainBundle] bundleIdentifier];
}