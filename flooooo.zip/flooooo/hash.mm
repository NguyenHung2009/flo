#import "API/VoVong.h"
#import "mahoa.h"
#import <Foundation/Foundation.h>
NSString * const __kHashDefaultValue = NSSENCRYPT("39beb0e4a214d4d56107cd4f81861516");