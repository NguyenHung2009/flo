#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
extern NSString * const __kHashDefaultValue;
@interface vovongios : NSObject

extern NSString * const __kHashDefaultValue;

@end
