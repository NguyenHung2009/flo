#include "THPatchMem.h"
#include <mach/mach.h>
#include <cstring>
#include <unistd.h>
#include <iostream>
#include <malloc/_malloc.h>

bool THPatchMem::patchMemory(void* address, uint8_t* buffer, size_t bufferSize) {
    if (!address || !buffer || bufferSize == 0) {
        std::cerr << "[THPatchMem] Invalid arguments." << std::endl;
        return false;
    }

    // Get the page size and calculate the page-aligned start address
    vm_size_t pageSize = (vm_size_t)getpagesize();
    uintptr_t pageStart = (uintptr_t)address & ~(pageSize - 1);
    size_t pageOffset = (uintptr_t)address - pageStart;

    mach_port_t selfTask = mach_task_self();
    kern_return_t kr;

    // Change memory protections to writable
    kr = vm_protect(selfTask, pageStart, pageSize, false, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
    if (kr != KERN_SUCCESS) {
        std::cerr << "[THPatchMem] vm_protect failed: " << mach_error_string(kr) << std::endl;
        return false;
    }

    // Write the buffer to memory
    std::memcpy((void*)(pageStart + pageOffset), buffer, bufferSize);

    // Restore original memory protections (read + execute)
    kr = vm_protect(selfTask, pageStart, pageSize, false, VM_PROT_READ | VM_PROT_EXECUTE);
    if (kr != KERN_SUCCESS) {
        std::cerr << "[THPatchMem] vm_protect restore failed: " << mach_error_string(kr) << std::endl;
        return false;
    }

    return true;
}
uint8_t* THPatchMem::ReadMemAtAddr(unsigned long long address, size_t size) {
    if (size == 0 || address == 0) {
        std::cerr << "Error: Invalid address or size." << std::endl;
        return nullptr; // Trả về nullptr nếu có lỗi
    }

    uint8_t *buffer = (uint8_t*)malloc(size); 
    if (buffer == nullptr) {
        std::cerr << "Error: Failed to alloc mem for buffer." << std::endl;
        return nullptr;
    }

    vm_size_t bytesRead = 0;
    kern_return_t kr = vm_read_overwrite(mach_task_self(), address, size, (vm_address_t)buffer, &bytesRead);

    if (kr != KERN_SUCCESS || bytesRead != size) {
        std::cerr << "Error: vm_read_overwrite failed for address: 0x" << std::hex << address 
                  << ", size: " << size << ". Error code: " << kr << std::endl;
        free(buffer);
        return nullptr;
    }
    return buffer; 
}