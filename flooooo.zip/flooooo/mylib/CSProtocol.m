// CSProtocol.m
#import "CSProtocol.h"

@implementation HeroSkin

- (instancetype)initWithHeroID:(uint32_t)heroID skinID:(uint32_t)skinID {
    self = [super init];
    if (self) {
        _heroID = heroID;
        _skinID = skinID;
    }
    return self;
}

@end

@implementation CSProtocol

- (instancetype)init {
    self = [super init];
    if (self) {
        _enable = NO;
        _heroSkinArray = [NSMutableArray array];
        [self loadHeroSkinArrayFromFile];
    }
    return self;
}

- (void)setEnable:(BOOL)isEnabled {
    _enable = isEnabled;
}
- (BOOL)isEnabled {
    return self.enable;
}
- (void)checkAndUpdateHeroSkin:(uint32_t)wheroID skinID:(uint32_t)wskinID {
    BOOL found = NO;
    for (HeroSkin *heroSkin in self.heroSkinArray) {
        if (heroSkin.heroID == wheroID) {
            heroSkin.skinID = wskinID;
            found = YES;
            break;
        }
    }
    if (!found) {
        HeroSkin *newHeroSkin = [[HeroSkin alloc] initWithHeroID:wheroID skinID:wskinID];
        [self.heroSkinArray addObject:newHeroSkin];
    }
    [self saveHeroSkinArrayToFile];
}
- (void)saveHeroSkinArrayToFile {
    NSArray<NSString *> *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = paths[0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"OSK.hpp"];
    
    NSMutableString *fileContent = [NSMutableString string];
    for (HeroSkin *heroSkin in self.heroSkinArray) {
        [fileContent appendFormat:@"%u,%u\n", heroSkin.heroID, heroSkin.skinID];
    }
    
    NSError *error = nil;
    BOOL success = [fileContent writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (!success) {
        NSLog(@"Error saving file: %@", error.localizedDescription);
    }
}
- (void)loadHeroSkinArrayFromFile {
    NSArray<NSString *> *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = paths[0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"OSK.hpp"];
    NSString *filePath2 = [documentsDirectory stringByAppendingPathComponent:@"Loadsucess.hpp"];
    NSError *error = nil;
    NSString *fileContent = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        NSLog(@"Error reading file: %@", error.localizedDescription);
        return;
    }
    //NSString *successMessage = @"Load thành công";
    //NSError *error1 = nil;
    //BOOL success1 = [successMessage writeToFile:filePath2 atomically:YES encoding:NSUTF8StringEncoding error:&error1];
    
    if (fileContent) {
        NSArray *lines = [fileContent componentsSeparatedByString:@"\n"];
        for (NSString *line in lines) {
            NSArray *components = [line componentsSeparatedByString:@","];
            if (components.count == 2) {
                uint32_t heroID = (uint32_t)[components[0] intValue];
                uint32_t skinID = (uint32_t)[components[1] intValue];
                HeroSkin *heroSkin = [[HeroSkin alloc] initWithHeroID:heroID skinID:skinID];
                [self.heroSkinArray addObject:heroSkin];
            }
        }
    }
    
}
- (BOOL)checkHeroID:(uint32_t)wheroID {
    BOOL found = NO;
    for (HeroSkin *heroSkin in self.heroSkinArray) {
        if (heroSkin.heroID == wheroID) {
            found = YES;
            break;
        }
    }
    return found; 
}
- (void)addHeroSkin:(HeroSkin *)heroSkin {
    [self.heroSkinArray addObject:heroSkin];
}
- (void)updateHeroSkin:(HeroSkin *)heroSkin {
    for (HeroSkin *heroSkin in self.heroSkinArray) {
        if (heroSkin.heroID == heroSkin.heroID) {
            heroSkin.skinID = heroSkin.skinID;
            break;
        }
    }
}
- (int)getHeroSkinID:(uint32_t)wheroID {
    for (HeroSkin *heroSkin in self.heroSkinArray) {
        if (heroSkin.heroID == wheroID) {
            return heroSkin.skinID;
        }
    }
    return 0;
}
- (NSMutableArray<HeroSkin *> *)getHeroSkinArray {
    return self.heroSkinArray;
}
@end
