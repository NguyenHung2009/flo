#import <mach/mach.h>
#import <mach-o/loader.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import "MerOsdk.h"
#import "MerO.h"


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>


@interface TimerView()
@property (nonatomic, strong) NSTimer *MerOsdk;


@end

 BOOL AntiHooK = NO;
static dispatch_once_t hookOnceToken;
static ssize_t (*orig_send)(int, const void *, size_t, int);

ssize_t hook_send(int sockfd, const void *buf, size_t len, int flags) {
    if (AntiHooK) {
        NSLog(@"[Hook] AntiHook enabled. Blocking send.");
        return 0;
    }
    return orig_send(sockfd, buf, len, flags);
}

@implementation TimerView

+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        TimerView *view = [TimerView Timer];
        [view start];
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        if (keyWindow) {
            [keyWindow addSubview:view];
            NSLog(@"[TimerView] Added to keyWindow.");
        } else {
            NSLog(@"[TimerView] Failed to add view to keyWindow.");
        }
    });
}

+ (instancetype)Timer {
    return [[self alloc] initWithFrame:[UIScreen mainScreen].bounds];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
    }
    return self;
}

- (void)XHLJ {
    AntiHooK = YES;
    
    // Hook chỉ thực hiện một lần
    dispatch_once(&hookOnceToken, ^{
        struct rebinding send_rebinding = {
            "send",
            hook_send,
            (void *)&orig_send
        };
        
        int result = rebind_symbols(&send_rebinding, 1);
        if (result != 0) {
            NSLog(@"[Hook] Failed to rebind 'send': %d", result);
        } else {
            NSLog(@"[Hook] Successfully rebound 'send'.");
        }
    });
}

- (void)start {
    self.MerOsdk.fireDate = [NSDate distantPast];
    NSLog(@"[TimerView] Timer started.");
}

- (NSTimer *)MerOsdk {
    if (!_MerOsdk) {
        __weak typeof(self) weakSelf = self;
        _MerOsdk = [NSTimer scheduledTimerWithTimeInterval:0.1
                                                   repeats:YES
                                                     block:^(NSTimer * _Nonnull timer) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (AntiHooK) {
                [strongSelf XHLJ];
                NSLog(@"[TimerView] Hook called continuously.");
            }
        }];
    }
    return _MerOsdk;
}

- (void)dealloc {
    [_MerOsdk invalidate];
    _MerOsdk = nil;
    NSLog(@"[TimerView] Timer invalidated and view deallocated.");
}

@end