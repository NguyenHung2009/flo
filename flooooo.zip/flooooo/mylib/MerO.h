

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TimerView : UIView

+ (instancetype)Timer;

- (void)start;
//+ (void)kaiguanToushis: (UISwitch*) zhuangtai;
@end

NS_ASSUME_NONNULL_END
