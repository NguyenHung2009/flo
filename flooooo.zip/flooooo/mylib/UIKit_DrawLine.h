#import <UIKit/UIKit.h>

@interface LineDrawingView : UIView

@property (nonatomic, strong) NSMutableDictionary<NSNumber *, CAShapeLayer *> *lineLayers;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, NSArray<NSValue *> *> *boxes;
- (void)updateOrCreateLineWithID:(uint64_t)lineID from:(CGPoint)startPoint to:(CGPoint)endPoint withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)removeLineWithID:(uint64_t)lineID;
- (void)removeAllLines;
- (void)updateOrCreate3DBoxWithID:(uint64_t)boxID vertices:(NSArray<NSValue *> *)vertices withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)remove3DBoxWithID:(uint64_t)boxID;
- (void)add3DBoxWithID:(uint64_t)boxID vertices:(NSArray<NSValue *> *)vertices withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)animate3DBoxWithID:(uint64_t)boxID toVertices:(NSArray<NSValue *> *)vertices duration:(CFTimeInterval)duration;
@end

@implementation LineDrawingView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _lineLayers = [NSMutableDictionary dictionary];
        _boxes = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)updateOrCreateLineWithID:(uint64_t)lineID from:(CGPoint)startPoint to:(CGPoint)endPoint withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    NSNumber *lineKey = [NSNumber numberWithUnsignedLongLong:lineID];
    CAShapeLayer *lineLayer = self.lineLayers[lineKey];
    
    if (lineLayer) {
        [self animateLine:lineLayer to:endPoint duration:0.1];
    } else {
        lineLayer = [CAShapeLayer layer];
        [self.layer addSublayer:lineLayer];
        
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path moveToPoint:startPoint];
        [path addLineToPoint:endPoint];
        
        lineLayer.path = path.CGPath;
        lineLayer.strokeColor = color.CGColor;
        lineLayer.lineWidth = lineWidth;
        self.lineLayers[lineKey] = lineLayer;
    }
}

- (void)animateLine:(CAShapeLayer *)lineLayer to:(CGPoint)newEndPoint duration:(CFTimeInterval)duration {
    UIBezierPath *newPath = [UIBezierPath bezierPath];
    [newPath moveToPoint:CGPointMake(self.bounds.size.width / 2, 45)];
    [newPath addLineToPoint:newEndPoint];
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"path"];
    animation.fromValue = (__bridge id)(lineLayer.path);
    animation.toValue = (__bridge id)(newPath.CGPath);
    animation.duration = duration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    lineLayer.path = newPath.CGPath;
    [lineLayer addAnimation:animation forKey:@"lineAnimation"];
}

- (void)removeLineWithID:(uint64_t)lineID {
    NSNumber *lineKey = [NSNumber numberWithUnsignedLongLong:lineID];
    CAShapeLayer *lineLayer = self.lineLayers[lineKey];
    
    if (lineLayer) {
        [lineLayer removeFromSuperlayer];
        [self.lineLayers removeObjectForKey:lineKey];
    }
}

- (void)removeAllLines {
    for (CAShapeLayer *lineLayer in self.lineLayers.allValues) {
        [lineLayer removeFromSuperlayer];
    }
    [self.lineLayers removeAllObjects];
}
- (void)updateOrCreate3DBoxWithID:(uint64_t)boxID vertices:(NSArray<NSValue *> *)vertices withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    if (vertices.count != 8) {
        return;
    }
    NSNumber *boxKey = [NSNumber numberWithUnsignedLongLong:boxID];
    if (self.boxes[boxKey]) {
        [self animate3DBoxWithID:boxID color:color toVertices:vertices duration:0.5];
    } else {
        [self add3DBoxWithID:boxID vertices:vertices withColor:color lineWidth:lineWidth];
    }
}

- (void)add3DBoxWithID:(uint64_t)boxID vertices:(NSArray<NSValue *> *)vertices withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    NSNumber *boxKey = [NSNumber numberWithUnsignedLongLong:boxID];
    self.boxes[boxKey] = vertices;
    [self draw3DBoxWithVertices:vertices boxID:boxID withColor:color lineWidth:lineWidth];
}

- (void)animate3DBoxWithID:(uint64_t)boxID color:(UIColor *)color toVertices:(NSArray<NSValue *> *)vertices duration:(CFTimeInterval)duration {
    NSNumber *boxKey = [NSNumber numberWithUnsignedLongLong:boxID];
    NSArray<NSValue *> *currentVertices = self.boxes[boxKey];
    
    if (currentVertices) {
        NSArray<NSArray<NSNumber *> *> *edges = @[
            @[@0, @1], @[@1, @2], @[@2, @3], @[@3, @0], // mặt dưới
            @[@4, @5], @[@5, @6], @[@6, @7], @[@7, @4], // mặt trên
            @[@0, @4], @[@1, @5], @[@2, @6], @[@3, @7]  // các cạnh đứng
        ];
        
        for (NSArray<NSNumber *> *edge in edges) {
            CGPoint startPoint = [currentVertices[edge[0].intValue] CGPointValue];
            CGPoint endPoint = [vertices[edge[1].intValue] CGPointValue];
            [self updateOrCreateLineWithID:boxID from:startPoint to:endPoint withColor:color lineWidth:1.0];
        }
        self.boxes[boxKey] = vertices;
    }
}

- (void)draw3DBoxWithVertices:(NSArray<NSValue *> *)vertices boxID:(uint64_t)boxID withColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    NSArray<NSArray<NSNumber *> *> *edges = @[
        @[@0, @1], @[@1, @2], @[@2, @3], @[@3, @0], // mặt dưới
        @[@4, @5], @[@5, @6], @[@6, @7], @[@7, @4], // mặt trên
        @[@0, @4], @[@1, @5], @[@2, @6], @[@3, @7]  // các cạnh đứng
    ];
    
    for (NSArray<NSNumber *> *edge in edges) {
        CGPoint startPoint = [vertices[edge[0].intValue] CGPointValue];
        CGPoint endPoint = [vertices[edge[1].intValue] CGPointValue];
        [self updateOrCreateLineWithID:boxID from:startPoint to:endPoint withColor:color lineWidth:lineWidth];
    }
}

- (void)remove3DBoxWithID:(uint64_t)boxID {
    NSNumber *boxKey = [NSNumber numberWithUnsignedLongLong:boxID];
    NSArray<NSValue *> *vertices = self.boxes[boxKey];
    
    if (vertices) {
        NSArray<NSArray<NSNumber *> *> *edges = @[
            @[@0, @1], @[@1, @2], @[@2, @3], @[@3, @0], // mặt dưới
            @[@4, @5], @[@5, @6], @[@6, @7], @[@7, @4], // mặt trên
            @[@0, @4], @[@1, @5], @[@2, @6], @[@3, @7]  // các cạnh đứng
        ];
        
        for (NSArray<NSNumber *> *edge in edges) {
            CGPoint startPoint = [vertices[edge[0].intValue] CGPointValue];
            CGPoint endPoint = [vertices[edge[1].intValue] CGPointValue];
            [self removeLineWithID:boxID];
        }
        
        [self.boxes removeObjectForKey:boxKey];
    }
}
@end
