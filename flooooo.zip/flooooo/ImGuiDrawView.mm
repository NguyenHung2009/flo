// ✅ Chặn host AOV / GARENA - ngăn quét tài khoản
#import <Foundation/Foundation.h>

@interface BlockAOV : NSURLProtocol
@end

@implementation BlockAOV
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    NSString *host = request.URL.host.lowercaseString;
    NSArray *blockedHosts = @[
        @"aov.garena.vn",
        @"game.aov.garena.vn",
        @"api-aov.garena.com",
        @"dl.garenanow.com",
        @"sdk.garena.com",
        @"app-measurement.com",
        @"garena.vn"
    ];
    for (NSString *blocked in blockedHosts) {
        if ([host containsString:blocked]) {
            NSLog(@"❌ Blocked AOV Host: %@", host);
            return YES;
        }
    }
    return NO;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    return request;
}
- (void)startLoading {
    [self.client URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:-1009 userInfo:nil]];
}
- (void)stopLoading {}
@end

__attribute__((constructor)) static void initBlockAOV(void) {
    [NSURLProtocol registerClass:[BlockAOV class]];
}

#import "NemG.h"
#import "NemGz.h"

#import "myhack/Handle.h"

@interface ImGuiDrawView () <MTKViewDelegate, UITextFieldDelegate, UIColorPickerViewControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) UIPickerView *pickerViewName;

@end
UIColor *kCyberpunkPrimaryColor = [UIColor redColor]; // Đổi ở đây
UIView *view;
UIImageView *GifView;
NSString *bundle;
NSString *ver;
int isPrimaryColorPicker = 0;
bool isMenuVisible = false;
bool loaddata = true;
static NSUInteger currentTab = 0;

NSArray *AimConfigs = @[nssoxorany("Máu thấp nhất"),nssoxorany("Máu % thấp nhất"),nssoxorany("Gần khoảng cách nhất"),nssoxorany("Gần hướng nhất")];
NSArray *NameConfigs = @[nssoxorany("Name Original"),nssoxorany("Get Name CD"),nssoxorany("Name Options"),nssoxorany("Get Name Hero")];
#define kCustomGrayColor [UIColor colorWithRed:117 / 255.0 green:117 / 255.0 blue:117 / 255.0 alpha:1.0]

// Cyberpunk Hologram Theme Colors
#define kCyberpunkBackgroundColor [UIColor colorWithRed:0.05 green:0.05 blue:0.1 alpha:0.9]
extern UIColor *kCyberpunkPrimaryColor;
#define kCyberpunkSecondaryColor [UIColor colorWithRed:1.0 green:0.0 blue:0.8 alpha:1.0] // Neon Pink
#define kCyberpunkAccentColor [UIColor colorWithRed:1.0 green:1.0 blue:0.0 alpha:1.0] // Neon Yellow
#define kCyberpunkTextColor [UIColor whiteColor]
 
@implementation ImGuiDrawView
NSTimer *updateTimer;
ImFont *_espFont;

#include "header.h"



- (void)Menucuatoi {
    [self updateSwitchStates];

    // Kích thước và vị trí menu
    CGRect menuFrame = CGRectMake(70, 90, 480, 360);
    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;

    // Tạo text field (có thể nhập text nếu cần, ở đây dùng để bọc menu)
    textField = [[CustomTextField alloc] initWithFrame:menuFrame];
    textField.secureTextEntry = boolUS[12];
    textField.subviews.firstObject.userInteractionEnabled = YES;
    textField.userInteractionEnabled = YES;
    textField.hidden = NO;
    textField.center = [self calculateMenuCenter];

    // Tạo menu view chính
    menuView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 480, 360)];
    menuView.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.95]; // nền tối trong suốt nhẹ
    menuView.layer.cornerRadius = 24.0; // ✅ Bo tròn góc mạnh hơn
    menuView.layer.masksToBounds = YES;  // ✅ Đảm bảo các góc được bo đều
    menuView.layer.borderWidth = 1.0f;
    menuView.layer.borderColor = [UIColor colorWithRed:1 green:0.2 blue:0.5 alpha:0.4].CGColor; // viền mỏng mờ hồng tím
    menuView.layer.shadowColor = [UIColor blackColor].CGColor;
    menuView.layer.shadowRadius = 12.0f;
    menuView.layer.shadowOpacity = 0.35f;
    menuView.layer.shadowOffset = CGSizeMake(0, 6);

    // Kéo thả menu
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [textField addGestureRecognizer:panGesture];

    // Gắn view menu vào textField, rồi hiển thị lên cửa sổ
    [textField.subviews.firstObject addSubview:menuView];
    [mainWindow addSubview:textField];

    // Vẽ đường nét viền hiện đại uốn lượn bằng các đoạn line
    [self drawLineWithStartPoint:CGPointMake(30, 30) endPoint:CGPointMake(450, 30) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(450, 30) endPoint:CGPointMake(460, 50) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(460, 50) endPoint:CGPointMake(460, 310) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(460, 310) endPoint:CGPointMake(440, 330) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(440, 330) endPoint:CGPointMake(40, 330) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(40, 330) endPoint:CGPointMake(30, 310) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(30, 310) endPoint:CGPointMake(30, 30) color:[UIColor magentaColor] width:1.0f inView:menuView];    [self drawLineWithStartPoint:CGPointMake(440, 330) endPoint:CGPointMake(40, 330) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(40, 330) endPoint:CGPointMake(30, 310) color:[UIColor magentaColor] width:1.0f inView:menuView];
    [self drawLineWithStartPoint:CGPointMake(30, 310) endPoint:CGPointMake(30, 30) color:[UIColor magentaColor] width:1.0f inView:menuView];

    
    

     TitleGui = [self createLabelWithText:nssoxorany("MENU 157X") size:35 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(72, 12, 250, 35)];
     [menuView addSubview:TitleGui];


    TitleGui2 = [self createLabelWithText:nssoxorany("Group Telegram THẦY DŨNG") size:10 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(188, 70, 112, 13)];
    [menuView addSubview:TitleGui2];

    Mainbutton[7] = [self createButtonWithType:UIButtonTypeSystem frame:CGRectMake(420, 20, 24, 42) imageName:nssoxorany("xmark") action:@selector(closeMenu) color:kCyberpunkPrimaryColor];
    [menuView addSubview:Mainbutton[7]];
    
    NSArray *frames = @[
        [NSValue valueWithCGRect:CGRectMake(54, 96, 40, 40)],
        [NSValue valueWithCGRect:CGRectMake(54, 144, 40, 40)],
        [NSValue valueWithCGRect:CGRectMake(54, 192, 40, 40)],
        [NSValue valueWithCGRect:CGRectMake(54, 240, 40, 40)],
        [NSValue valueWithCGRect:CGRectMake(54, 288, 40, 40)]
    ];
    NSArray *imageNames = @[nssoxorany("house"), nssoxorany("scope"), nssoxorany("arkit"), nssoxorany("hand.raised.fill"), nssoxorany("gear")];
    for (NSUInteger i = 0; i < imageNames.count; i++) {
        Mainbutton[i] = [self createButtonWithType:UIButtonTypeSystem frame:[frames[i] CGRectValue] imageName:imageNames[i] action:@selector(ButtonTapped:) color:kCyberpunkPrimaryColor];
        [menuView addSubview:Mainbutton[i]];
    }

    [self TabHome];
    [self TabAim];
    [self TabESP];
    [self TabBT];
    [self TabSetting];
    [self ButtonTapped:Mainbutton[0]];
}

- (void)drawLineWithStartPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint color:(UIColor *)color width:(CGFloat)width inView:(UIView *)view {
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:startPoint];
    [path addLineToPoint:endPoint];

    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = path.CGPath;
    shapeLayer.strokeColor = color.CGColor;
    shapeLayer.lineWidth = width;

    [view.layer addSublayer:shapeLayer];
}

- (void)TabHome {
    int x = 135;
    int y = 130;
    // Tạo UIImageView hack
    
    
    UILabel *TitleHome = [self createLabelWithText:nssoxorany("‍MAIN FUNCTION") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(130.8, 96, 140, 10.5)];
    TitleHome.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    TitleHome.layer.shadowRadius = 5.0f;
    TitleHome.layer.shadowOpacity = 0.9f;
    TitleHome.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome];
    UILabel *TitleHome2 = [self createLabelWithText:nssoxorany("‍CÁC CHỨC NĂNG CƠ BẢN ĐÃ BẬT\nHIDE NAME BẬT Ở SẢNH") size:7 color:kCyberpunkPrimaryColor numberOfLines:0 frame:CGRectMake(291.6, 90, 170, 20.2)];
    TitleHome2.layer.shadowColor = kCyberpunkSecondaryColor.CGColor;
    TitleHome2.layer.shadowRadius = 5.0f;
    TitleHome2.layer.shadowOpacity = 0.9f;
    TitleHome2.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome2];
    NSArray *switchConfigs = @[
        @{nssoxorany("title"): nssoxorany("HACK MAP"), nssoxorany("subtitle"): nssoxorany("Hiển thị tầm nhìn"), nssoxorany("x"): @0, nssoxorany("y"): @0},
        @{nssoxorany("title"): nssoxorany("NAME CHANGE"), nssoxorany("subtitle"): nssoxorany("Đổi tên toàn bộ (Sảnh)"), nssoxorany("x"): @150, nssoxorany("y"): @0},
        @{nssoxorany("title"): nssoxorany("MÁY YẾU"), nssoxorany("subtitle"): nssoxorany("Dành cho máy yếu"), nssoxorany("x"): @0, nssoxorany("y"): @40},
        @{nssoxorany("title"): nssoxorany("HIDE NAME"), nssoxorany("subtitle"): nssoxorany("Bật ở sảnh"), nssoxorany("x"): @150, nssoxorany("y"): @40},
        @{nssoxorany("title"): nssoxorany("UNLOCK SKIN"), nssoxorany("subtitle"): nssoxorany("Mở khóa skin"), nssoxorany("x"): @0, nssoxorany("y"): @80},
        @{nssoxorany("title"): nssoxorany("LOCK CAMERA"), nssoxorany("subtitle"): nssoxorany("Khóa camera Elsu"), nssoxorany("x"): @150, nssoxorany("y"): @80}
    ];

    for (int i = 0; i < 6; i++) {
        [self createControlPair:YES index:i title:switchConfigs[i][nssoxorany("title")] subtitle:switchConfigs[i][nssoxorany("subtitle")] frame:CGRectMake(x + [switchConfigs[i][nssoxorany("x")] intValue], y + [switchConfigs[i][nssoxorany("y")] intValue], 51, 32)];
    }
    UILabel *DroneView = [self createLabelWithText:nssoxorany("SLIDER CAMERA") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(139, 250.416, 150, 10.5)];
    DroneView.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    DroneView.layer.shadowRadius = 5.0f;
    DroneView.layer.shadowOpacity = 0.9f;
    DroneView.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:DroneView];
    gach = [self drawLineAtPosition:CGPointMake(302.4, 261.6) width:138 height:1 color:kCyberpunkPrimaryColor inView:menuView];
    gach.hidden = NO;
    float fsavedValue = (float)[[NSUserDefaults standardUserDefaults] floatForKey:@"Slider4"];
    NSDictionary *sliderAndLabel = [self createCustomSliderAtPosition:CGPointMake(135, 270) withSize:CGSizeMake(280, 25) minimumValue:0.1 maximumValue:4.0 value:fsavedValue selector:@selector(SliderChange:) format:nssoxorany("%.2fm[CAMERA]") inView:menuView];
    Slider[4] = sliderAndLabel[@"slider"];
    SliderLabel[4] = sliderAndLabel[@"label"];
}

- (void)TabAim {
    int x = 135;
    int y = 130;
    
    
    UILabel *TitleHome = [self createLabelWithText:nssoxorany("‍AIM OPTIONS") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(130.8, 96, 140, 10.5)];
    TitleHome.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    TitleHome.layer.shadowRadius = 5.0f;
    TitleHome.layer.shadowOpacity = 0.9f;
    TitleHome.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome];

    UILabel *TitleHome2 = [self createLabelWithText:nssoxorany("‍CÁC CHỨC NĂNG CƠ BẢN ĐÃ BẬT\nHIDE NAME BẬT Ở SẢNH") size:7 color:kCyberpunkPrimaryColor numberOfLines:0 frame:CGRectMake(291.6, 90, 170, 20.2)];
    TitleHome2.layer.shadowColor = kCyberpunkSecondaryColor.CGColor;
    TitleHome2.layer.shadowRadius = 5.0f;
    TitleHome2.layer.shadowOpacity = 0.9f;
    TitleHome2.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome2];
    [self createControlPair:YES index:9 title:nssoxorany("AIM PREDICTED") subtitle:nssoxorany("AIM BOT HERO")  frame:CGRectMake(x, y, 51, 32)];
    [self createControlPair:YES index:1 title:nssoxorany("NAME CHANGE") subtitle:nssoxorany("ĐỔI TÊN TÙY CHỌN")  frame:CGRectMake(x+150, y, 51, 32)];
    [self createControlPair:YES index:19 title:nssoxorany("MACRO FLO") subtitle:nssoxorany("FLORENTINO")  frame:CGRectMake(x, y+80, 51, 32)];
    [self createControlPair:YES index:20 title:nssoxorany("VỊ TRÍ BÔNG HOA") subtitle:nssoxorany("HIỆN VỊ TRÍ HOA")  frame:CGRectMake(x+150, y+80, 51, 32)];
    [self createControlPair:NO index:15 title:nssoxorany("AUTO COMBO SKILL 1") subtitle:nssoxorany("SỬ DỤNG SKILL1")  frame:CGRectMake(x, y+120, 20, 20)];
    [self createControlPair:NO index:16 title:nssoxorany("AUTO COMBO SKILL 3") subtitle:nssoxorany("SỬ DỤNG SKILL3")  frame:CGRectMake(x+150, y+120, 20, 20)];

/*
// Tạo nút "TEST SELL" với kích thước tương tự
[self createControlPair:YES index:33 title:nssoxorany("BÁN ĐỒ") subtitle:nssoxorany("KHI HẾT MÁU") frame:CGRectMake(x, y + 160, 51, 32)];

// Tạo nút "TEST BUY" với kích thước tương tự
[self createControlPair:YES index:34 title:nssoxorany("MUA ĐỒ") subtitle:nssoxorany("MUA ĐỒ NHANH") frame:CGRectMake(x + 150, y + 160, 51, 32)];
*/
    
    self.pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(x, y +80, 280, 80)];
    self.pickerView.delegate = self;
    self.pickerView.hidden = YES;
    self.pickerView.dataSource = self;
    [menuView addSubview:self.pickerView];
    self.pickerViewName = [[UIPickerView alloc] initWithFrame:CGRectMake(x, y +80, 280, 80)];
    self.pickerViewName.delegate = self;
    self.pickerViewName.hidden = YES;
    self.pickerViewName.dataSource = self;
    [menuView addSubview:self.pickerViewName];
    int savedAimMode = [[NSUserDefaults standardUserDefaults] integerForKey:@"choiseLabel"];
    choiseLabel = [self createLabelWithText:[NSString stringWithFormat:nssoxorany("%@"), AimConfigs[savedAimMode]] size:14 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(x, y + 40, 120, 25)];
    [menuView addSubview:choiseLabel];
    int savedNameMode = [[NSUserDefaults standardUserDefaults] integerForKey:@"choiseLabelName"];
    choiseLabelName = [self createLabelWithText:[NSString stringWithFormat:nssoxorany("%@"), NameConfigs[savedNameMode]] size:14 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(x+150, y + 40, 120, 25)];
    [menuView addSubview:choiseLabelName];
    UIButton *dropdownButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [dropdownButton setTitle:@"▼" forState:UIControlStateNormal];
    [dropdownButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [dropdownButton addTarget:self action:@selector(showPicker) forControlEvents:UIControlEventTouchUpInside];
    dropdownButton.frame = CGRectMake(x+120, y+40, 40, 25); 
    [menuView addSubview:dropdownButton];
    UIButton *dropdownButton1 = [UIButton buttonWithType:UIButtonTypeSystem];
    [dropdownButton1 setTitle:@"▼" forState:UIControlStateNormal];
    [dropdownButton1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [dropdownButton1 addTarget:self action:@selector(showPickerName) forControlEvents:UIControlEventTouchUpInside];
    dropdownButton1.frame = CGRectMake(x+270, y+40, 40, 25); 
    [menuView addSubview:dropdownButton1];
    /* float isavedValue = (float)[[NSUserDefaults standardUserDefaults] floatForKey:@"Slider5"];
    NSDictionary *sliderAndLabel1 = [self createCustomSliderAtPosition:CGPointMake(x, y + 120) withSize:CGSizeMake(280, 25) minimumValue:0.0 maximumValue:10.00 value:isavedValue selector:@selector(SliderChange:) format:@"%.2fm/s[Tốc Đạn]" inView:menuView];
    Slider[5] = sliderAndLabel1[@"slider"];
    SliderLabel[5] = sliderAndLabel1[@"label"]; */
    FieldName[0] = [[UITextField alloc] initWithFrame:CGRectMake(135, 306, 280, 25)];
    FieldName[0].borderStyle = UITextBorderStyleRoundedRect;
    FieldName[0].layer.cornerRadius = FieldName[0].frame.size.height / 2;
    FieldName[0].layer.masksToBounds = YES;
    FieldName[0].placeholder = nssoxorany("Nhập tên muốn đổi...");
    FieldName[0].textColor = [UIColor whiteColor];
    FieldName[0].backgroundColor = kCyberpunkBackgroundColor;
    FieldName[0].layer.borderColor = kCyberpunkPrimaryColor.CGColor;
    FieldName[0].layer.borderWidth = 1.0f;
    FieldName[0].delegate = self;
    [menuView addSubview:FieldName[0]];
    NSString *savedFieldName = [[NSUserDefaults standardUserDefaults] objectForKey:@"FieldNameValue"];
    if (savedFieldName) {
        FieldName[0].text = savedFieldName;
    }
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [menuView addGestureRecognizer:tapGesture];
}

- (void)TabBT {
    int x = 135;
    int y = 130;
    
    
    UILabel *TitleHome = [self createLabelWithText:nssoxorany("‍BỔ TRỢ") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(130.8, 96, 140, 10.5)];
    TitleHome.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    TitleHome.layer.shadowRadius = 5.0f;
    TitleHome.layer.shadowOpacity = 0.9f;
    TitleHome.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome];

    UILabel *TitleHome2 = [self createLabelWithText:nssoxorany("‍TỰ ĐỘNG SỬ DỤNG BỔ TRỢ \nDÀNH CHO CỤT TAY") size:7 color:kCyberpunkPrimaryColor numberOfLines:0 frame:CGRectMake(291.6, 90, 170, 20.2)];
    TitleHome2.layer.shadowColor = kCyberpunkSecondaryColor.CGColor;
    TitleHome2.layer.shadowRadius = 5.0f;
    TitleHome2.layer.shadowOpacity = 0.9f;
    TitleHome2.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome2];
    [self createControlPair:YES index:13 title:nssoxorany("BĂNG SƯƠNG") subtitle:nssoxorany("TỰ ĐỘNG BĂNG SƯƠNG")  frame:CGRectMake(x, y, 51, 32)];
    [self createControlPair:YES index:14 title:nssoxorany("BỘC PHÁ") subtitle:nssoxorany("AUTO BỘC PHÁ")  frame:CGRectMake(x, y+35, 51, 32)];
    [self createControlPair:YES index:24 title:nssoxorany("TRỪNG TRỊ") subtitle:nssoxorany("AITO TRỪNG TRỊ")  frame:CGRectMake(x, y+105, 51, 32)];
    [self createControlPair:YES index:23 title:nssoxorany("SPAM CHAT") subtitle:nssoxorany("SPAM CHAT 20 LẦN")  frame:CGRectMake(x, y+140, 51, 32)];
    [self createControlPair:YES index:21 title:nssoxorany("NGẮT ANTIHOOK") subtitle:nssoxorany("DỪNG ANTIHOOK")  frame:CGRectMake(x, y+175, 51, 32)];
    float bsbt = (float)[[NSUserDefaults standardUserDefaults] floatForKey:nssoxorany("Slider0")];
    NSDictionary *sliderAndLabel1 = [self createCustomSliderAtPosition:CGPointMake(x+150, y) withSize:CGSizeMake(150, 25) minimumValue:0.0 maximumValue:100.00 value:bsbt selector:@selector(SliderChange:) format:@"%.2f%HP" inView:menuView];
    float bpbt = (float)[[NSUserDefaults standardUserDefaults] floatForKey:nssoxorany("Slider1")];
    NSDictionary *sliderAndLabel3 = [self createCustomSliderAtPosition:CGPointMake(x+150, y+35) withSize:CGSizeMake(150, 25) minimumValue:0.0 maximumValue:15.00 value:bpbt selector:@selector(SliderChange:) format:@"%.2f%HP" inView:menuView];
    Slider[0] = sliderAndLabel1[@"slider"];
    SliderLabel[0] = sliderAndLabel1[@"label"];
    Slider[1] = sliderAndLabel3[@"slider"];
    SliderLabel[1] = sliderAndLabel3[@"label"];
}
- (void) TabESP
{
    int x = 135;
    int y = 130;
        
    
    UILabel *TitleHome = [self createLabelWithText:nssoxorany("‍ESP FUNCTION") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(130.8, 96, 140, 10.5)];
    TitleHome.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    TitleHome.layer.shadowRadius = 5.0f;
    TitleHome.layer.shadowOpacity = 0.9f;
    TitleHome.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome];
    UILabel *TitleHome2 = [self createLabelWithText:nssoxorany("‍CÁC CHỨC NĂNG CƠ BẢN ĐÃ BẬT\nESP DEMO TEST") size:7 color:kCyberpunkPrimaryColor numberOfLines:0 frame:CGRectMake(291.6, 90, 170, 20.2)];
    TitleHome2.layer.shadowColor = kCyberpunkSecondaryColor.CGColor;
    TitleHome2.layer.shadowRadius = 5.0f;
    TitleHome2.layer.shadowOpacity = 0.9f;
    TitleHome2.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome2];
    NSArray *switchConfigs = @[
    @{nssoxorany("title"): nssoxorany("ESP ENABLE"), nssoxorany("subtitle"): nssoxorany("Mở để sử dụng"), nssoxorany("x"): @0, nssoxorany("y"): @0, nssoxorany("index"): @11},
    @{nssoxorany("title"): nssoxorany("LIVE STREAM"), nssoxorany("subtitle"): nssoxorany("Ẩn Hack khi livestream"), nssoxorany("x"): @150, nssoxorany("y"): @0, nssoxorany("index"): @12}
    ];
    NSArray *checkboxConfigs = @[
        @{nssoxorany("title"): nssoxorany("PlayerLine"), nssoxorany("x"): @10, nssoxorany("y"): @40, nssoxorany("index"): @0},
        @{nssoxorany("title"): nssoxorany("PlayerDot"), nssoxorany("x"): @110, nssoxorany("y"): @40, nssoxorany("index"): @1},
        @{nssoxorany("title"): nssoxorany("PlayerBox3D"), nssoxorany("x"): @200, nssoxorany("y"): @40, nssoxorany("index"): @2},
        @{nssoxorany("title"): nssoxorany("PlayerDistance"), nssoxorany("x"): @10, nssoxorany("y"): @70, nssoxorany("index"): @3},
        @{nssoxorany("title"): nssoxorany("PlayerAlert"), nssoxorany("x"): @110, nssoxorany("y"): @70, nssoxorany("index"): @4},
        @{nssoxorany("title"): nssoxorany("PlayerCd"), nssoxorany("x"): @200, nssoxorany("y"): @70, nssoxorany("index"): @6},
        @{nssoxorany("title"): nssoxorany("PlayerName"), nssoxorany("x"): @10, nssoxorany("y"): @100, nssoxorany("index"): @7},
        @{nssoxorany("title"): nssoxorany("Nhìn thấy"), nssoxorany("x"): @110, nssoxorany("y"): @100, nssoxorany("index"): @8},
        @{nssoxorany("title"): nssoxorany("Icon Bổ trợ"), nssoxorany("x"): @200, nssoxorany("y"): @100, nssoxorany("index"): @9},
        @{nssoxorany("title"): nssoxorany("Icon Tướng"), nssoxorany("x"): @10, nssoxorany("y"): @130, nssoxorany("index"): @10},
        @{nssoxorany("title"): nssoxorany("Icon Minimap"), nssoxorany("x"): @110, nssoxorany("y"): @130, nssoxorany("index"): @11},
        @{nssoxorany("title"): nssoxorany("PlayerBox2D"), nssoxorany("x"): @200, nssoxorany("y"): @130, nssoxorany("index"): @12},
    ];
    [switchConfigs enumerateObjectsUsingBlock:^(NSDictionary *config, NSUInteger idx, BOOL *stop) {
        [self createControlPair:YES  index:[config[nssoxorany("index")] intValue] title:config[nssoxorany("title")] subtitle:config[nssoxorany("subtitle")]
            frame:CGRectMake(x + [config[nssoxorany("x")] intValue], y + [config[nssoxorany("y")] intValue],  51, 32)];
    }];
    [checkboxConfigs enumerateObjectsUsingBlock:^(NSDictionary *config, NSUInteger idx, BOOL *stop) {
        [self createControlPair:NO  index:[config[nssoxorany("index")] intValue] title:config[nssoxorany("title")] subtitle:nil
            frame:CGRectMake(x + [config[nssoxorany("x")] intValue], y + [config[nssoxorany("y")] intValue], 20, 20)];
    }];
    float fsavedValue = (float)[[NSUserDefaults standardUserDefaults] floatForKey:@"Slider3"];
    NSDictionary *sliderAndLabel = [self createCustomSliderAtPosition:CGPointMake(x+5, y+180) withSize:CGSizeMake(280, 25) minimumValue:20.0 maximumValue:60.0 value:fsavedValue selector:@selector(SliderChange:) format:nssoxorany("%.2fm[ICON SIZE]") inView:menuView];
    Slider[3] = sliderAndLabel[@"slider"];
    SliderLabel[3] = sliderAndLabel[@"label"];
}
- (void) TabSetting
{
    int x = 135;
    int y = 130;
        
    
    UILabel *TitleHome = [self createLabelWithText:nssoxorany("‍COLOR SETTING") size:14 color:kCyberpunkPrimaryColor numberOfLines:1 frame:CGRectMake(130.8, 96, 140, 10.5)];
    TitleHome.layer.shadowColor = kCyberpunkPrimaryColor.CGColor;
    TitleHome.layer.shadowRadius = 5.0f;
    TitleHome.layer.shadowOpacity = 0.9f;
    TitleHome.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome];
    UILabel *TitleHome2 = [self createLabelWithText:nssoxorany("‍CHỌN MÀU ESP VÀ MENU") size:7 color:kCyberpunkPrimaryColor numberOfLines:0 frame:CGRectMake(291.6, 90, 170, 20.2)];
    TitleHome2.layer.shadowColor = kCyberpunkSecondaryColor.CGColor;
    TitleHome2.layer.shadowRadius = 5.0f;
    TitleHome2.layer.shadowOpacity = 0.9f;
    TitleHome2.layer.shadowOffset = CGSizeZero;
    [menuView addSubview:TitleHome2];
    NSArray *colorPickerConfigs = @[
        @{nssoxorany("title"): nssoxorany("Color Box3D"), nssoxorany("x"): @150, nssoxorany("y"): @0, nssoxorany("action"): @"showColorPicker"},
        @{nssoxorany("title"): nssoxorany("Menu Color"), nssoxorany("x"): @20, nssoxorany("y"): @0, nssoxorany("action"): @"showColorPicker1"},
        @{nssoxorany("title"): nssoxorany("Color Line"), nssoxorany("x"): @150, nssoxorany("y"): @60, nssoxorany("action"): @"showColorPicker2"},
        @{nssoxorany("title"): nssoxorany("Color Text"), nssoxorany("x"): @20, nssoxorany("y"): @60, nssoxorany("action"): @"showColorPicker3"}
    ];

    for (NSDictionary *config in colorPickerConfigs) {
        UILabel *colorPickLabel = [self createLabelWithText:config[nssoxorany("title")] size:14 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(x + [config[nssoxorany("x")] floatValue], y + [config[nssoxorany("y")] floatValue], 100, 20)];
        [menuView addSubview:colorPickLabel];

        NSInteger index = [colorPickerConfigs indexOfObject:config];
        ColorPick[index] = [self createButtonWithType:UIButtonTypeSystem frame:CGRectMake(x + [config[nssoxorany("x")] floatValue] + 30, y + [config[nssoxorany("y")] floatValue] + 20, 40, 40) imageName:nssoxorany("paintbrush") action:NSSelectorFromString(config[nssoxorany("action")]) color:[UIColor whiteColor]];
        [menuView addSubview:ColorPick[index]];
        colorselected[index] = [[UILabel alloc] initWithFrame:CGRectMake(x+[config[nssoxorany("x")] floatValue] -10, y + [config[nssoxorany("y")] floatValue] + 25, 30, 30)];
        colorselected[index].backgroundColor = [self convertImGuiColorToUIColor:selectedImGuiColor[index]];
        [menuView addSubview:colorselected[index]];
    }
}

- (void)textFieldDidChange:(NSNotification *)notification {
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (CAShapeLayer*)drawLineAtPosition:(CGPoint)position width:(CGFloat)width height:(CGFloat)height color:(UIColor *)color inView:(UIView *)view {
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    lineLayer.frame = CGRectMake(position.x, position.y, width, height);
    lineLayer.backgroundColor = [UIColor clearColor].CGColor;

    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, 0)];
    [path addLineToPoint:CGPointMake(width, 0)];

    lineLayer.path = path.CGPath;
    lineLayer.strokeColor = color.CGColor;
    lineLayer.lineWidth = height;
    
    // Add a glowing effect
    lineLayer.shadowColor = color.CGColor;
    lineLayer.shadowRadius = 5.0f;
    lineLayer.shadowOpacity = 0.9f;
    lineLayer.shadowOffset = CGSizeZero;
    
    [view.layer addSublayer:lineLayer];
    return lineLayer;
}
- (NSDictionary *)createCustomSliderAtPosition:(CGPoint)position withSize:(CGSize)size minimumValue:(float)minValue maximumValue:(float)maxValue
                    value:(float)initialValue selector:(SEL)selector format:(NSString *)formatString inView:(UIView *)menuView {
    
    UIView *sliderBackground = [[UIView alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    sliderBackground.backgroundColor = [UIColor lightGrayColor];
    sliderBackground.layer.cornerRadius = size.height / 2;
    [menuView addSubview:sliderBackground];

    UISlider *floatSlider = [[UISlider alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    floatSlider.minimumValue = minValue;
    floatSlider.maximumValue = maxValue;
    floatSlider.value = initialValue > 0 ? initialValue : minValue;
    [floatSlider setMinimumTrackTintColor:[UIColor clearColor]];
    [floatSlider setMaximumTrackTintColor:[UIColor clearColor]];
    [floatSlider setThumbTintColor:kCyberpunkPrimaryColor];
    [menuView addSubview:floatSlider];
    
    UILabel *flabel = [[UILabel alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    flabel.textColor = [UIColor whiteColor];
    flabel.textAlignment = NSTextAlignmentCenter;
    flabel.text = [NSString stringWithFormat:formatString, floatSlider.value];
    [floatSlider addTarget:self action:selector forControlEvents:UIControlEventValueChanged];
    [menuView addSubview:flabel];
    return @{nssoxorany("slider"): floatSlider, nssoxorany("label"): flabel};
}
- (UILabel *)createLabelWithText:(NSString *)text size:(int)size color:(UIColor *)color numberOfLines:(int)numberOfLines frame:(CGRect)frame {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.textColor = color;
    label.text = text;
    label.font = [UIFont systemFontOfSize:size];
    label.numberOfLines = numberOfLines;
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}
- (void)createControlPair:(BOOL)isSwitch index:(int)idx title:(NSString *)title subtitle:(NSString *)subtitle frame:(CGRect)frame {
    if (isSwitch) {
        US[idx] = [self createSwitchWith2Text:title text2:subtitle frame:frame inView:menuView action:@selector(SWTapped)];
        [menuView addSubview:US[idx]];
    } 
    else 
    {
        SW[idx] = [self createCheckboxWithFrame:frame title:title size:10 color:kCyberpunkPrimaryColor action:@selector(SWTapped)];
        [menuView addSubview:SW[idx]];
    }
}
- (UISwitch *)createSwitchWithText:(NSString *)text frame:(CGRect)frame inView:(UIView *)view action:(SEL)action{
    UISwitch *switchControl = [[UISwitch alloc] initWithFrame:frame];
    switchControl.onTintColor = kCyberpunkPrimaryColor;
    [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
    [view addSubview:switchControl];
    UILabel *label = [self createLabelWithText:text size:14 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x +50, frame.origin.y-5, 130, 40)];
    [view addSubview:label];
    return switchControl;
}
- (UISwitch *)createSwitchWith2Text:(NSString *)text1 text2:(NSString *)text2 frame:(CGRect)frame inView:(UIView *)view action:(SEL)action{
    UISwitch *switchControl = [[UISwitch alloc] initWithFrame:frame];
    switchControl.onTintColor = kCyberpunkPrimaryColor;
    switchControl.tintColor = [UIColor colorWithWhite:0.39 alpha:0.73];
    [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
    [view addSubview:switchControl];
    UILabel *label = [self createLabelWithText:text1 size:12 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x + 50, frame.origin.y - 0, 130, 20)];
    [view addSubview:label];
    UILabel *label2 = [self createLabelWithText:text2 size:8 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x + 50, frame.origin.y + 12, 130, 20)];
    [view addSubview:label2];
    return switchControl;
}
- (CustomCheckbox *)createCheckboxWithFrame:(CGRect)frame title:(NSString *)title size:(int)size color:(UIColor *)color action:(SEL)action{
    CustomCheckbox *checkbox = [[CustomCheckbox alloc] initWithFrame:frame title:title size:size color:color];
    checkbox.backgroundColorUnchecked = [UIColor clearColor];
    checkbox.backgroundColorChecked = [UIColor clearColor];
    checkbox.borderColor = color;
    checkbox.label.textColor = [UIColor whiteColor];
    // Add a glowing effect to the checkbox label
    checkbox.label.layer.shadowColor = color.CGColor;
    checkbox.label.layer.shadowRadius = 5.0f;
    checkbox.label.layer.shadowOpacity = 0.9f;
    checkbox.label.layer.shadowOffset = CGSizeZero;
    [checkbox addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    return checkbox;
}
- (UIButton *)createButtonWithType:(UIButtonType)type frame:(CGRect)frame imageName:(NSString *)imageName action:(SEL)action color:(UIColor *)color {
    UIButton *button = [UIButton buttonWithType:type];
    button.frame = frame;
    UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:35.0 weight:UIImageSymbolWeightRegular scale:UIImageSymbolScaleDefault];
    UIImage *image = [UIImage systemImageNamed:imageName withConfiguration:config];
    [button setImage:image forState:UIControlStateNormal];  
    [button setTintColor:color];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (textField == FieldName[0]) {
        [defaults setObject:textField.text forKey:nssoxorany("FieldNameValue")];
    } else if (textField == FieldName[1]) {
        [defaults setObject:textField.text forKey:nssoxorany("FieldName1Value")];
    }
    [defaults synchronize];
    return YES;
}

- (void)SliderChange:(UISlider *)slider {
    float value = slider.value;
    NSArray *formats = @[
        nssoxorany("%.2f%HP"),
                nssoxorany("%.2f%HP"),
        nssoxorany("%d Hz"),            
        nssoxorany("%.2fm[ICON SIZE]"), 
        nssoxorany("%.2fm[CAMERA]"),    
        nssoxorany("%.2fm/s[Tốc Đạn]")  
    ];
    for (int i = 0; i < soluong; i++) {
        if(slider == Slider[i])
        {
            if (i != 2) 
            {
                SliderLabel[i].text = [NSString stringWithFormat:formats[i], value];
            } 
            else if (i == 2) 
            {
                int value1 = (int)round(value);
                SliderLabel[2].text = [NSString stringWithFormat:formats[2], value1];
                
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                [defaults setInteger:value1 forKey:nssoxorany("Slider2")];
                [defaults synchronize];
                return;
            }
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setFloat:value forKey:[NSString stringWithFormat:nssoxorany("Slider%d"), i]];
            [defaults synchronize];
        }
    }
}
- (void)startHackViewAnimation:(UIImageView *)hackView originX:(CGFloat)originX  targetX:(CGFloat)targetX{
    CGFloat originalX = originX;
    [UIView animateWithDuration:2.0 delay:1.0 options:UIViewAnimationOptionCurveEaseInOut 
        animations:^{
            hackView.frame = CGRectMake(targetX, hackView.frame.origin.y, hackView.frame.size.width, hackView.frame.size.height);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:1.0 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut 
                animations:^{
                    hackView.transform = CGAffineTransformMakeScale(-1, 1);
                } completion:^(BOOL finished) {
                    [UIView animateWithDuration:2.0  delay:0.0  options:UIViewAnimationOptionCurveEaseInOut 
                        animations:^{
                            hackView.frame = CGRectMake(originalX, hackView.frame.origin.y, hackView.frame.size.width, hackView.frame.size.height);
                } completion:^(BOOL finished) {
                hackView.transform = CGAffineTransformIdentity; 
                    //[self startHackViewAnimation:hackView originX:originalX targetX:targetX];
            }];
        }];
    }];
}
- (void)updateLabels {
    if(MenDeal){
        copyright.text = [NSString stringWithFormat:nssoxorany("%d %d %d"),giatriInt[19],giatriInt[18],giatriInt[17]];
        colorselected[0].backgroundColor = [self convertImGuiColorToUIColor:selectedImGuiColor[0]];
        colorselected[1].backgroundColor = [self convertImGuiColorToUIColor:selectedImGuiColor[1]];
        colorselected[2].backgroundColor = [self convertImGuiColorToUIColor:selectedImGuiColor[2]];
        colorselected[3].backgroundColor = [self convertImGuiColorToUIColor:selectedImGuiColor[3]];
        if (selectedImGuiColor[1].x == 0 && selectedImGuiColor[1].y == 0 && selectedImGuiColor[1].z == 0 && selectedImGuiColor[1].w == 0) {
            kCyberpunkPrimaryColor = [UIColor redColor];
        } else {
            kCyberpunkPrimaryColor = [self convertImGuiColorToUIColor:selectedImGuiColor[1]];
        }

        textField.secureTextEntry = boolUS[12];
    }
}
- (void)dismissKeyboard {
    [menuView endEditing:YES];
    self.pickerView.hidden = YES;
}
- (void)handlePan:(UIPanGestureRecognizer *)gesture {
    CGPoint translation = [gesture translationInView:gesture.view.superview];
    CGPoint newCenter = CGPointMake(gesture.view.center.x + translation.x, gesture.view.center.y + translation.y);
    CGFloat dampingFactor = 0.8f;
    newCenter.x = Lerp(gesture.view.center.x, newCenter.x, dampingFactor);
    newCenter.y = Lerp(gesture.view.center.y, newCenter.y, dampingFactor);
    gesture.view.center = newCenter;
    [gesture setTranslation:CGPointZero inView:gesture.view.superview];
    if (gesture.state == UIGestureRecognizerStateEnded) {
        [UIView animateWithDuration:kAnimationDuration delay:0 usingSpringWithDamping:0.5 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            gesture.view.center = [self calculateMenuCenter];
        } completion:nil];
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setFloat:gesture.view.center.x forKey:nssoxorany("menuViewCenterX")];
    [defaults setFloat:gesture.view.center.y forKey:nssoxorany("menuViewCenterY")];
    [defaults synchronize];
}
- (void)closeMenu {  
    if (menuView) {
        textField.hidden = YES;
        textField.userInteractionEnabled = NO;
        isMenuVisible = NO;
        [updateTimer invalidate];
        updateTimer = nil;
        MenDeal = false;
    }
} 
- (void)showColorPicker {
    isPrimaryColorPicker = 1; 
    UIColorPickerViewController *colorPicker = [[UIColorPickerViewController alloc] init];
    colorPicker.delegate = self;
    [self presentViewController:colorPicker animated:YES completion:nil];
}

- (void)showColorPicker1 {
    isPrimaryColorPicker = 2;
    UIColorPickerViewController *colorPicker = [[UIColorPickerViewController alloc] init];
    colorPicker.delegate = self;
    [self presentViewController:colorPicker animated:YES completion:nil];
}
- (void)showColorPicker2 {
    isPrimaryColorPicker = 3;
    UIColorPickerViewController *colorPicker = [[UIColorPickerViewController alloc] init];
    colorPicker.delegate = self;
    [self presentViewController:colorPicker animated:YES completion:nil];
}
- (void)showColorPicker3 {
    isPrimaryColorPicker = 4;
    UIColorPickerViewController *colorPicker = [[UIColorPickerViewController alloc] init];
    colorPicker.delegate = self;
    [self presentViewController:colorPicker animated:YES completion:nil];
}
- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)viewController {
    UIColor *selectedColor = viewController.selectedColor;
    selectedImGuiColor[isPrimaryColorPicker-1] = [self convertUIColorToImGuiColor:selectedColor];
    [self SWTapped];
    [self ButtonTapped:Mainbutton[4]];
}
- (ImVec4)convertUIColorToImGuiColor:(UIColor *)color {
    CGFloat red, green, blue, alpha;
    [color getRed:&red green:&green blue:&blue alpha:&alpha];
    return ImVec4((float)red, (float)green, (float)blue, (float)alpha);
}
- (UIColor *)convertImGuiColorToUIColor:(ImVec4)color {
    return [UIColor colorWithRed:color.x green:color.y blue:color.z alpha:color.w];
}
- (void)SWTapped {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    for (int i = 0; i < soluong; i++) {
        [defaults setBool:SW[i].checked forKey:[NSString stringWithFormat:nssoxorany("sw%d"), i]];
        boolSW[i] = SW[i].checked;
        
    }
    for (int i = 0; i < soluong; i++) {
        [defaults setBool:US[i].isOn forKey:[NSString stringWithFormat:nssoxorany("us%d"), i]];
        boolUS[i] = US[i].isOn;
    }
    
    [defaults setInteger:aimMode forKey:nssoxorany("choiseLabel")];
    [defaults setInteger:NameMode forKey:nssoxorany("choiseLabelName")];
    for (NSInteger i = 0; i < 4; i++) {
        [defaults setFloat:selectedImGuiColor[i].x forKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldX"), (long)(i + 1)]];
        [defaults setFloat:selectedImGuiColor[i].y forKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldY"), (long)(i + 1)]];
        [defaults setFloat:selectedImGuiColor[i].z forKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldZ"), (long)(i + 1)]];
        [defaults setFloat:selectedImGuiColor[i].w forKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldW"), (long)(i + 1)]];
    }
    
    [defaults synchronize];
}

- (void)updateSwitchStates {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    for (int i = 0; i < soluong; i++) {
        SW[i].checked = [defaults boolForKey:[NSString stringWithFormat:nssoxorany("sw%d"), i]];
        boolSW[i] = SW[i].checked;
    }
    for (int i = 0; i < soluong; i++) {
        US[i].on = [defaults boolForKey:[NSString stringWithFormat:nssoxorany("us%d"), i]];
        boolUS[i] = US[i].isOn;
    }
    aimMode = [defaults integerForKey:nssoxorany("choiseLabel")];
    NameMode = [defaults integerForKey:nssoxorany("choiseLabelName")];
    for (NSInteger i = 0; i < 4; i++) {
        selectedImGuiColor[i] = (ImVec4){
            [defaults floatForKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldX"), (long)(i + 1)]],
            [defaults floatForKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldY"), (long)(i + 1)]],
            [defaults floatForKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldZ"), (long)(i + 1)]],
            [defaults floatForKey:[NSString stringWithFormat:nssoxorany("selectedImGuiColor%ldW"), (long)(i + 1)]]
        };
    }
    // Kiểm tra giá trị mặc định cho màu GUI
    if (selectedImGuiColor[1].x == 0 && selectedImGuiColor[1].y == 0 && selectedImGuiColor[1].z == 0 && selectedImGuiColor[1].w == 0) {
        kCyberpunkPrimaryColor = [UIColor redColor];
    } else {
        kCyberpunkPrimaryColor = [self convertImGuiColorToUIColor:selectedImGuiColor[1]];
    }
    NSString *savedFieldName = [defaults objectForKey:nssoxorany("FieldNameValue")];
    if (savedFieldName) {
        FieldName[0].text = savedFieldName;
    }
}
- (void)bellButtonTapped:(UIButton *)sender {
}
- (void)ButtonTapped:(UIButton *)sender {
    [self clearMenu];
    for (NSUInteger i = 0; i < 6; i++) {
                UIButton *button = Mainbutton[i];
        [button setTintColor:kCustomGrayColor];
        if (button == sender) {
            currentTab = i;
        }
    }
    switch (currentTab) {
        case 0:
            [self TabHome];
            break;
        case 1:
            [self TabAim];
            break;
        case 2:
            [self TabESP];
            break;
        case 3:
            [self TabBT];
            break;
        case 4:
            [self TabSetting];
            break;
    }
    [Mainbutton[currentTab] setTintColor:kCyberpunkPrimaryColor];
    [self updateSwitchStates];
}
- (CGPoint)calculateMenuCenter {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    CGFloat centerX = [defaults floatForKey:nssoxorany("menuViewCenterX")];
    CGFloat centerY = [defaults floatForKey:nssoxorany("menuViewCenterY")];
    
    return CGPointMake(
        centerX > 0 ? centerX : CGRectGetMidX([UIScreen mainScreen].bounds),
        centerY > 0 ? centerY : CGRectGetMidY([UIScreen mainScreen].bounds)
    );
}
- (void)clearMenu{
    for (UIView *subview in [menuView subviews]) {
        [subview removeFromSuperview];
    }
    gach.hidden = YES;
    [menuView.layer addSublayer:innerRectLayer];
    [menuView.layer addSublayer:innerRectLayer1];
    [menuView addSubview:imageView];
    imageView.tintColor = kCyberpunkPrimaryColor;
    Mainbutton[6].tintColor = kCyberpunkPrimaryColor;
    Mainbutton[7].tintColor = kCyberpunkPrimaryColor;
    [menuView addSubview:TitleGui];
    [menuView addSubview:TitleGui2];
    [menuView addSubview:copyright];
    for (NSUInteger i = 0; i < 8; i++) {
        [menuView addSubview:Mainbutton[i]];
    }
}
- (void)showPicker {
    self.pickerView.hidden = !self.pickerView.hidden;
}
- (void)showPickerName {
    self.pickerViewName.hidden = !self.pickerViewName.hidden;
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView == self.pickerView) {
        return 4;
    } else if (pickerView == self.pickerViewName) {
        return 4;
    }
    return 0;
}
- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSString *title;
    if (pickerView == self.pickerView) {
        title = AimConfigs[row];
    } else if (pickerView == self.pickerViewName) {
        title = NameConfigs[row];
    }
    NSDictionary *attributes = @{
        NSForegroundColorAttributeName: [UIColor whiteColor],
        NSFontAttributeName: [UIFont systemFontOfSize:12]
    };
    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
}
- (void)dismissPicker {
    self.pickerView.hidden = YES;
    self.pickerViewName.hidden = YES;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (pickerView == self.pickerView) {
        [self.pickerView selectRow:row inComponent:0 animated:YES];
        aimMode = row;
        choiseLabel.text = [NSString stringWithFormat:nssoxorany("%@"), AimConfigs[row]];
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setInteger:row forKey:nssoxorany("choiseLabel")];
        [defaults synchronize];
    } else if (pickerView == self.pickerViewName) {
        [self.pickerViewName selectRow:row inComponent:0 animated:YES];
        NameMode = row;
        choiseLabelName.text = [NSString stringWithFormat:nssoxorany("%@"), NameConfigs[row]];
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setInteger:row forKey:nssoxorany("choiseLabelName")];
        [defaults synchronize];
    }

}
- (void)keyPressed:(UIKeyCommand *)keyCommand {
    if ([keyCommand.input isEqualToString:@"n"]) {
        [self showPicker];
    }
}
@end