#import <UIKit/UIKit.h>
#import <UIKit/UIColorPickerViewController.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIAlertView.h>
#import <UIKit/UIControl.h>
#include <unordered_map>
#include <string>
#include <fstream>
#include <thread>
#include <chrono> 
using namespace std::chrono;
#include <sstream>
#include <map>
#include <set>
#include <deque>
#include <vector>
#include <array>
#include <CoreFoundation/CoreFoundation.h>
#include <sys/sysctl.h>
#import <sys/utsname.h>
#include <iostream>
#include <mach-o/dyld.h>
#include <mach-o/getsect.h>
#include <mach/mach.h>
#include <dlfcn.h>
#include <libgen.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <cstdint> 
#include <cstdlib> 
#include <ctime>
#import "../mylib/dobby.h"
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#include "../imgui/imgui_impl_metal.h"
#import "../LoadView/ImGuiDrawView.h"
#import "../Utils/EspManager.h"
#import "../mylib/CTCheckbox.h"
#import "../mylib/CSProtocol.h"
#import "../mylib/Herolib.h"
#include "../LoadView/Includes.h"
#import "../Utils/hack/Function.h"
//#import "../LoadView/LoadView.h"
#import <GLKit/GLKit.h>
#import <OpenGLES/ES3/gl.h>
#import <OpenGLES/ES3/glext.h>
#import <math.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import "../LoadView/DTTJailbreakDetection.h"
#import "../mylib/il2cpp.h"
#import "../imgui/imgui_additional.h"
#import "../Utils/Macros.h"
#import "../ESP.h"
#import "../Utils/Unity.h"
#import "../mylib/NakanoYotsuba.h"
#import "../Utils/hack/VInt3.h"
#import "../mylib/THPatchMem.h"
//#import "../mylib/FireWall.h"
#import "../Frameworks/JRMemory.framework/Headers/MemScan.h"
#import "../mylib/MerO.h"


#import "../mylib/hook.h"
#define _CRT_SECURE_NO_WARNINGS
#define STB_IMAGE_IMPLEMENTATION
#import "../imgui/stb_image.h"
#define HOOK_DOPA(offset, ptr, orig) DobbyHook((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)
#define HOOK_Anogs(offset, ptr, orig) DobbyHook((void *)getRealOffset1(offset), (void *)ptr, (void **)&orig)
#define HOOK_OFF(offset) DobbyDestroy((void *)offset)
#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define gWidth kWidth*kScale
#define gHeight kHeight*kScale
#define soluong 40
bool giatriBool[soluong] = {false};
bool boolUS[soluong] = {false};
bool boolSW[soluong] = {false};
bool activeALL = true;
bool anogpass = false;
int aimMode =0,NameMode = 0;
int giatriInt[soluong] = {0};
float giatriFloat[soluong] = {0};
float offx = 50.0f;
float offy = 1.0f;
int skillid ;
int herroid = 0;
int skillSlot;
char giatri[256];
int indexname = 0;
char tenstr[256];
bool isFirst = true;
extern bool Chongto;
extern bool AntiHooK;
bool AntiDo = false;
ImVec4 selectedImGuiColor[4] = {ImVec4(0.0f, 1.0f, 1.0f, 1.0f), ImVec4(0.0f, 1.0f, 1.0f, 1.0f), ImVec4(0.0f, 1.0f, 1.0f, 1.0f), ImVec4(0.0f, 1.0f, 1.0f, 1.0f)};
UIColor *GuiColor = [UIColor greenColor];
NSString *playerNameNSString1;
vector<pair<uint64_t, string>> nameORG;
vector<pair<uint64_t, string>> nameHostORG;
@interface CustomTextField : UITextField
@end

@implementation CustomTextField
- (BOOL)canBecomeFirstResponder {
    return NO;
}
@end
struct PatchInfo {
    uint64_t address;
    char* buffer;
    bool* setting;
    bool isPatched;
};
vector<PatchInfo> patch_infos;
struct EntityInfo {
    Vector3 myPos;
	Vector3 enemyPos;
	Vector3 moveForward;
	int ConfigID;
	float bullettime;
    float Ranger;
    int currentSpeed; 
};
EntityInfo EnemyTarget;
static uint64_t offset[35];
static uint64_t Minimap[20];
static uint64_t ESP[100];
static uint64_t ModSkin[20];
static uint64_t AimAndBT[20];
static uint64_t SettingFPS[10];
static uint64_t Antiban[40];
static uint64_t BuyandSell[40];

CAShapeLayer *innerRectLayer,*innerRectLayer1;
CAShapeLayer *_innerRectLayer,*_innerRectLayer1;

UIImageView *imageView;

UIButton *ColorPick[soluong];
UIButton *Mainbutton[soluong];

UIWindow* mainWindow1;

UIView *menuView;
UISegmentedControl *segmentedControl;

UILabel *copyright, *colorselected[soluong];

UILabel *TitleGui,*TitleGui2;

UISlider *Slider[soluong] ;
UISlider *_Slider[soluong];
UITextField *FieldName[soluong];
CAShapeLayer *gach;
CustomCheckbox *SW[soluong];
CustomTextField *textField;
UISwitch *US[soluong];
UILabel *choiseLabel;
UILabel *choiseLabelName;
UILabel *SliderLabel[soluong];
CSProtocol *protocol = [[CSProtocol alloc] init];
ESPManager *espManager;
ESPManager *SkillSlotManager;
ESPManager *ActorLinker_enemy;
ESPManager *Flo_Enemy;
ESPManager *Flo_Hoa;
std::map<uint64_t, Vector3> previousEnemyPositions;
std::map<uint64_t, Vector3> passpostiton;

uint64_t get_offset(NSString *dllfilename, NSString *namespaze, NSString *className, NSString *methodName, int argsCount) {
    const char *dllfilenamec = [dllfilename UTF8String];
    const char *namespazec = [namespaze UTF8String];
    const char *classNamec = [className UTF8String];
    const char *methodNamec = [methodName UTF8String];
    uint64_t methodOffset;
    Il2CppAttach();

    Il2CppMethod& getClass(const char* namespazec, const char* classNamec);
    uint64_t getMethod(const char* methodNamec, int argsCount);

    Il2CppMethod methodAccess(dllfilenamec);
    methodOffset = methodAccess.getClass(namespazec, classNamec).getMethod(methodNamec, argsCount);
    return methodOffset;
}
uint64_t getFieldOffset(NSString *dllFilename, NSString *namespaceName, NSString *className, NSString *fieldName) {
    Il2CppField field([dllFilename UTF8String]);
    field.getClass([namespaceName UTF8String], [className UTF8String]);
    field.getField([fieldName UTF8String]);
    uint64_t offset = field.getOffset();
    return offset;
}
uint getskindata(uint64_t instance,const char* name)
{
    return *(uint*)(instance + getFieldOffset(NSSENCRYPT("AovTdr.dll"),NSSENCRYPT("CSProtocol"),NSSENCRYPT("COMDT_HERO_COMMON_INFO"),NSSENCRYPT(name)));
}

monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getRealOffset(offset[14]);
    return String_CreateString(NULL, str);
}
std::string NSStringToStdString(NSString *nsString) {
    const char *cString = [nsString UTF8String];
    return std::string(cString);
} 
NSString* ConvertMonoStringToNSString(MonoString* monoStr) {
    if (monoStr == nullptr) {
        return nil;
    }

    const char* utf8String = monoStr->toChars();
    NSString* result = [NSString stringWithUTF8String:utf8String];

    return result;
}
/*
uint64_t getRealOffset1(uint64_t offset){
	return getAbsoluteAddress("anogs", offset);
}
void ReadMem(void* addr, size_t length) {
    kern_return_t kr;
    vm_size_t region_size = 0;
    mach_port_t task = mach_task_self();  
    vm_address_t target_addr = (vm_address_t)addr;
    
  
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t info_count = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t object_name = MACH_PORT_NULL;

    
    kr = vm_region_64(task, &target_addr, &region_size, VM_REGION_BASIC_INFO_64,
                      (vm_region_info_t)&info, &info_count, &object_name);
    if (kr != KERN_SUCCESS) {
        NSLog(@"[ReadMem] Failed to query memory region: %s (code: %d)", mach_error_string(kr), kr);
        return;
    }

    
    if (!(info.protection & VM_PROT_READ)) {
        NSLog(@"[ReadMem] Memory is not readable at address: %p", addr);
        return;
    }

    
    void* buffer = malloc(length);
    if (buffer == NULL) {
        NSLog(@"[ReadMem] Failed to allocate buffer for reading memory.");
        return;
    }

    
    kr = vm_read(task, (vm_address_t)addr, length, (vm_offset_t*)&buffer, (mach_msg_type_number_t*)&length);
    if (kr != KERN_SUCCESS) {
        NSLog(@"[ReadMem] Failed to read memory: %s (code: %d)", mach_error_string(kr), kr);
        free(buffer);
        return;
    }

    
    NSLog(@"[ReadMem] Data read from address: %p", addr);
    NSLog(@"[ReadMem] Data: %@", [NSData dataWithBytes:buffer length:length]);

    free(buffer);
}
std::string uint64ToHex(uint64_t value) {
    std::stringstream ss;
    ss << "0x" << std::hex << value;
    return ss.str();
}
*/
/*
void saveToFile(std::string icon)
{
    NSArray<NSString *> *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = paths[0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"Test.txt"];
    std::ofstream outFile([filePath UTF8String], std::ios::app);
    if (!outFile.is_open()) {
        return;
    }
	outFile  << icon << std::endl;
    outFile.close();
}
void saveToFile(int giatri = 0)
{
    NSArray<NSString *> *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = paths[0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"Test.txt"];
    std::ofstream outFile([filePath UTF8String], std::ios::app);
    if (!outFile.is_open()) {
        return;
    }
	outFile << "giatri: " << giatri << std::endl;
    outFile.close();
}
*/

void thongbaowin() {
    NSString *messageText = nssoxorany("ĐÃ KẾT THÚC GAME");
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:14]};
    CGSize textSize = [messageText sizeWithAttributes:attributes];
    CGFloat padding = 20;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat alertWidth = textSize.width + padding * 2;
    CGFloat alertHeight = textSize.height + padding;
    CGFloat alertX = (screenWidth - alertWidth) / 2;
    //CGFloat alertY = screenHeight - alertHeight - 20; // Xuống dưới cùng màn hình, cách 20px
    CGFloat alertY = 20;
    UIColor *backgroundColor = [UIColor systemGray6Color];
    UIView *alertView = [[UIView alloc] initWithFrame:CGRectMake(alertX, alertY, alertWidth, alertHeight)];
    alertView.backgroundColor = backgroundColor;
    alertView.layer.cornerRadius = 10;
    alertView.layer.masksToBounds = YES;
    UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(padding, padding / 2, textSize.width, textSize.height)];
    messageLabel.text = messageText;
    CGFloat white = 0.0;
    [backgroundColor getWhite:&white alpha:nil];
    messageLabel.textColor = (white > 0.5) ? [UIColor blackColor] : [UIColor whiteColor];
    messageLabel.font = [UIFont systemFontOfSize:14];
    messageLabel.textAlignment = NSTextAlignmentCenter;
    [alertView addSubview:messageLabel];
    [hideRecordView addSubview:alertView];
    [UIView animateWithDuration:0.5 delay:4.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        alertView.alpha = 0;
    } completion:^(BOOL finished) {
        [alertView removeFromSuperview];
    }];
}
void thongbaohack() {
    NSString *messageText = nssoxorany("ĐÃ KÍCH HOẠT CHỐNG TỐ");
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:14]};
    CGSize textSize = [messageText sizeWithAttributes:attributes];
    CGFloat padding = 20;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat alertWidth = textSize.width + padding * 2;
    CGFloat alertHeight = textSize.height + padding;
    CGFloat alertX = (screenWidth - alertWidth) / 2;
    //CGFloat alertY = screenHeight - alertHeight - 20; // Xuống dưới cùng màn hình, cách 20px
    CGFloat alertY = 20;
    UIColor *backgroundColor = [UIColor systemGray6Color];
    UIView *alertView = [[UIView alloc] initWithFrame:CGRectMake(alertX, alertY, alertWidth, alertHeight)];
    alertView.backgroundColor = backgroundColor;
    alertView.layer.cornerRadius = 10;
    alertView.layer.masksToBounds = YES;
    UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(padding, padding / 2, textSize.width, textSize.height)];
    messageLabel.text = messageText;
    CGFloat white = 0.0;
    [backgroundColor getWhite:&white alpha:nil];
    messageLabel.textColor = (white > 0.5) ? [UIColor blackColor] : [UIColor whiteColor];
    messageLabel.font = [UIFont systemFontOfSize:14];
    messageLabel.textAlignment = NSTextAlignmentCenter;
    [alertView addSubview:messageLabel];
    [hideRecordView addSubview:alertView];
    [UIView animateWithDuration:0.5 delay:5.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        alertView.alpha = 0;
    } completion:^(BOOL finished) {
        [alertView removeFromSuperview];
    }];
}
