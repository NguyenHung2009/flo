#ifndef HANDLE_H
#define HANDLE_H
#import "Patches.h"
static bool loadoff = false;
void cheatHandle() {
	if(loadoff == false)
	{
		loadoff = true;
		offset[0] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LVActorLinker"),nssoxorany("SetVisible"), 3);

		offset[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CLobbySystem"),nssoxorany("OpenWaterMark"), 0);
		
		offset[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany(""),nssoxorany("CameraSystem"),nssoxorany("GetCameraHeightRateValue"), 1);
		offset[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany(""),nssoxorany("CameraSystem"),nssoxorany("Update"), 0);
		offset[6] = get_offset(nssoxorany("Project_d.dll"),nssoxorany(""),nssoxorany("CameraSystem"),nssoxorany("OnCameraHeightChanged"), 0);

		offset[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("HeroInfoPanel"),nssoxorany("ShowHeroInfo"), 2);
		offset[8] = get_offset(nssoxorany("Project_d.dll"),nssoxorany(""),nssoxorany("MiniMapHeroInfo"),nssoxorany("ShowHeroHpInfo"), 1);
		offset[9] = get_offset(nssoxorany("Project_d.dll"),nssoxorany(""),nssoxorany("MiniMapHeroInfo"),nssoxorany("ShowSkillStateInfo"), 1);
		offset[10] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("HeroSelectBanPickWindow"),nssoxorany("InitTeamHeroList"), 4);
		offset[11] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CPlayerProfile"),nssoxorany("get_IsHostProfile"), 0);
		offset[12] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("PVPLoadingView"),nssoxorany("checkTeamLaderGradeMax"), 1);
		offset[13] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("PVPLoadingView"),nssoxorany("OnEnter"), 0);
		offset[14] = get_offset(nssoxorany("mscorlib.dll"),nssoxorany("System"),nssoxorany("String"),nssoxorany("CreateString"), 1);
		offset[15] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("PhoneNotify"),nssoxorany("PhoneNotifySystem"),nssoxorany("_OnGameEnd"), 0);
		offset[16] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("PhoneNotify"),nssoxorany("PhoneNotifySystem"),nssoxorany("_OnGameStart"), 0);
    	offset[17] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"), nssoxorany("LFrameSyncBattleLogic"),nssoxorany("SendSyncData"), 2);
		offset[18] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.UI"), nssoxorany("CUIUtility"),nssoxorany("RemoveSpace"), 1);
		offset[19] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"), nssoxorany("CRoleInfo"),nssoxorany("IsNewbieFirstOperateBitSet"), 1);
		offset[20] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"), nssoxorany("InBattleMsgNetCore"),nssoxorany("SendInBattleMsg_InputChat"), 2);

		ESP[0] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("Update"), 0);
		ESP[1] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("LateUpdate"),0);
		ESP[2] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("IsHostPlayer"),0);
		ESP[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("IsHostCamp"),0);
		ESP[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_objType"),0);
		ESP[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_objCamp"),0);
		ESP[6] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_position"),0);
		ESP[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_HPBarVisible"),0);
		ESP[8] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_ObjID"),0);
		ESP[9] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_bVisible"),0);
		ESP[10] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("DestroyActor"),0);
		ESP[11] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("ValueComponent"));
		ESP[12] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("HudControl"));
		ESP[13] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("AsHero"),0);
		ESP[14] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("CharInfo"));
		
		ESP[15] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("get_forward"),0);
		ESP[16] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("get_location"),0);
		ESP[17] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("AsHero"),0);
		ESP[18] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("GiveMyEnemyCamp"),0);
		ESP[19] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("get_bActive"),0);
		ESP[20] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("get_ObjID"),0);
		ESP[21] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LObjWrapper"),nssoxorany("get_IsDeadState"),0);
		ESP[22] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LObjWrapper"),nssoxorany("IsAutoAI"),0);
		ESP[23] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("ValuePropertyComponent"),nssoxorany("get_actorHp"),0);
		ESP[24] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("ValuePropertyComponent"),nssoxorany("get_actorHpTotal"),0);
		ESP[25] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("UpdateLogic"),1);
		ESP[26] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("DestroyActor"),1);
		ESP[27] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("ValueComponent"));
		ESP[28] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("ActorControl"));

		ESP[29] = get_offset(nssoxorany("UnityEngine.CoreModule.dll"),nssoxorany("UnityEngine"),nssoxorany("Camera"),nssoxorany("get_main"), 0);
		ESP[30] = get_offset(nssoxorany("UnityEngine.CoreModule.dll"),nssoxorany("UnityEngine"),nssoxorany("Camera"),nssoxorany("WorldToScreenPoint"), 1);
		ESP[31] = get_offset(nssoxorany("UnityEngine.CoreModule.dll"),nssoxorany("UnityEngine"),nssoxorany("Camera"),nssoxorany("WorldToViewportPoint"), 1);
		ESP[32] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("HudComponent3D"),nssoxorany("SetPlayerName"), 4);
		ESP[33] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("SettlementHelper"),nssoxorany("SetPlayerName"), 2);
		
		ESP[34] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("CActorInfo"),nssoxorany("ActorName"));
		ESP[35] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("CActorInfo"),nssoxorany("hudHeight"));
		ESP[36] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("HeroWrapperData"),nssoxorany("heroWrapSkillData_1"));
		ESP[37] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("HeroWrapperData"),nssoxorany("heroWrapSkillData_2"));
		ESP[38] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("HeroWrapperData"),nssoxorany("heroWrapSkillData_3"));
		ESP[39] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("HeroWrapperData"),nssoxorany("heroWrapSkillData_5"));
		ESP[40] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Share"),nssoxorany("HeroWrapSkillData"),nssoxorany("Skill1SlotCD"));
		ESP[41] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("ObjLinker"));
		ESP[42] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("EquipComponent"));
		ESP[43] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("BuyEquip"),3);
		ESP[44] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("SellEquip"),1);
		ESP[45] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("EquipComponent"));
		ESP[46] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("GetEquips"),0);
		ESP[47] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("UpdateEquipEffect"),0);
		ESP[48] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("get_playerId"),0);
		ESP[49] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("SkillSlot"),nssoxorany("UpdateLogic"),1); 
		ESP[50] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("SkillSlot"),nssoxorany("get_SlotType"),0);
		ESP[51] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("SkillSlot"),nssoxorany("get_CurSkillCD"),0);
		ESP[52] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("ValuePropertyComponent"),nssoxorany("get_actorSoulLevel"), 0);
		ESP[53] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("ValuePropertyComponent"),nssoxorany("get_actorEp"), 0);
		ESP[54] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("ValuePropertyComponent"),nssoxorany("get_actorEpTotal"), 0);
		ESP[55] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LSkillComponent"),nssoxorany("GetSkillSlot"), 1);
		ESP[56] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("SkillSlot"),nssoxorany("get_RealSkillObj"), 0);
		ESP[57] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("SkillControl"));
		ESP[58] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("SkillSlot"),nssoxorany("<CurSkillCD>k__BackingField"));
		ESP[59] = get_offset(nssoxorany("UnityEngine.CoreModule.dll"),nssoxorany("UnityEngine"),nssoxorany("Camera"),nssoxorany("get_fieldOfView"), 0);
		ESP[60] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("get_EquipPassiveSkillInfoMap"),0);
		ESP[61] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("GetUsedRcmdEquipIds"),0);
		ESP[62] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("GetExistEquipInfoSet"),0);
		ESP[64] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LEquipComponent"),nssoxorany("GetCurrentActiveEquipId"),0);
		ESP[65] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("ObjLinker"));
		ESP[66] = getFieldOffset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LVActorLinker"),nssoxorany("Visible"));
		ESP[67] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LSpectatorMgr"),nssoxorany("SetVisible"), 2);
		ESP[68] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorLinker"),nssoxorany("EquipLinkerComp"));
		ESP[69] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("VEquipLinkerComponent"),nssoxorany("GetEquipActiveSkillCD"),1);
		ESP[70] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("VEquipLinkerComponent"),nssoxorany("GetEquipInfo"),1);
		
		ESP[80] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("BanPickPlayerItemView"),nssoxorany("SetPlayerName"), 1);
		ESP[81] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MatchingTeamPlayerView"),nssoxorany("SetPlayerInfoData"), 7);
		ESP[82] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios"),nssoxorany("KyriosFramework"),nssoxorany("get_actorManager"), 0);
		ESP[83] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ActorManager"),nssoxorany("GetAllMonsters"), 0);
		ESP[84] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ValueLinkerComponent"),nssoxorany("get_actorSoulLevel"),0);		
		ESP[85] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("ActorConfig"),nssoxorany("ConfigID"));
		
		

		Minimap[0] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("CurMapType"),0);
		Minimap[1] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("get_mmFinalScreenSize"),0);
		Minimap[2] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("get_bmFinalScreenSize"),0);
		Minimap[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("GetMMFianlScreenPos"),0);
		Minimap[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("GetBMFianlScreenPos"),0);
		Minimap[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MinimapSys"),nssoxorany("Update"),0);
		Minimap[6] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("MiniMapSysUT"),nssoxorany("Is3V3Minimap"),0);
		Minimap[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SLevelContext"),nssoxorany("IsNormal5v5Mode"),0);
		Minimap[8] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SLevelContext"),nssoxorany("get_bMiniMapBgFlip"),0);
		Minimap[9] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Share"),nssoxorany("SimpleLevelContext"),nssoxorany("IsTrainingMode"),0);
		Minimap[10] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SLevelContext"),nssoxorany("GetGameRoomType"),0);

		// Aim and Bo tro
		AimAndBT[0] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CSkillButtonManager"),nssoxorany("Update"), 0);
		AimAndBT[1] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CSkillButtonManager"),nssoxorany("CanRequestSkill"), 1);
	    AimAndBT[2] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CSkillButtonManager"),nssoxorany("GetCurSkillSlotType"), 0);
		AimAndBT[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CSkillButtonManager"),nssoxorany("RequestUseSkillSlot"), 4);
		AimAndBT[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillControlIndicator"),nssoxorany("GetUseSkillDirection"),1);
		AimAndBT[5] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillControlIndicator"),nssoxorany("curindicatorDistance"));
		AimAndBT[6] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillControlIndicator"),nssoxorany("useSkillDirection"));
		AimAndBT[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillSlot"),nssoxorany("LateUpdate"),1);
		AimAndBT[8] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillSlot"),nssoxorany("skillIndicator"));
		AimAndBT[9] = getFieldOffset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillSlot"),nssoxorany("SlotType"));
		AimAndBT[10] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ValueLinkerComponent"),nssoxorany("get_actorHp"),0);
		AimAndBT[11] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Kyrios.Actor"),nssoxorany("ValueLinkerComponent"),nssoxorany("get_actorHpTotal"),0);
		AimAndBT[12] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LActorRoot"),nssoxorany("get_PlayerMovement"),0);
		AimAndBT[13] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("PlayerMovement"),nssoxorany("get_speed"),0);
		AimAndBT[14] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CSkillButtonManager"),nssoxorany("ReadyUseSkillSlot"),2);
		AimAndBT[15] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("GameInput"),nssoxorany("SendMoveDirection"),2);
		AimAndBT[16] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillSlot"),nssoxorany("RequestUseSkill"), 0);
		AimAndBT[17] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("SkillSlot"),nssoxorany("ReadyUseSkill"), 1);
     	AimAndBT[18] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameLogic"),nssoxorany("GameInput"),nssoxorany("StopInput"),0);
		// ModSkin
		ModSkin[0] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CRoleInfo"),nssoxorany("IsHaveHeroSkin"), 3);
		ModSkin[1] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CRoleInfo"),nssoxorany("IsCanUseSkin"), 2);
		ModSkin[2] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CRoleInfo"),nssoxorany("GetHeroWearSkinId"), 1);	
		ModSkin[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CRoleInfo"),nssoxorany("IsPrimeFreeSkin"), 2);
		ModSkin[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("HeroSelectNormalWindow"),nssoxorany("OnClickSelectHeroSkin"), 2);
		ModSkin[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("HeroSelectNormalWindow"),nssoxorany("RefreshHeroPanel"), 3);
		ModSkin[6] = get_offset(nssoxorany("AovTdr.dll"),nssoxorany("CSProtocol"),nssoxorany("COMDT_HERO_COMMON_INFO"),nssoxorany("unpack"),2);
		ModSkin[7] = getFieldOffset(nssoxorany("AovTdr.dll"),nssoxorany("CSProtocol"),nssoxorany("COMDT_HERO_COMMON_INFO"),nssoxorany("dwHeroID"));
		ModSkin[8] = getFieldOffset(nssoxorany("AovTdr.dll"),nssoxorany("CSProtocol"),nssoxorany("COMDT_HERO_COMMON_INFO"),nssoxorany("wSkinID"));
		ModSkin[9] = get_offset(nssoxorany("AovTdr.dll"),nssoxorany("ResData"),nssoxorany("ResHeroSkin"),nssoxorany("unpack"),2);

		
		//supported fps
		SettingFPS[1] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("CheckSupported90And120FPS_Editor"), 3);
		SettingFPS[2] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("CheckDeviceSupport60FPSConfig"),0);
		SettingFPS[3] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("CheckDeviceSupport60FPS_CameraHeight_IOS"),0);
		SettingFPS[4] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("get_Supported60FPSMode"),0);
		SettingFPS[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("get_Supported90FPSMode"),0);
		SettingFPS[6] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("get_Supported120FPSMode"),0);
		SettingFPS[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.Framework"),nssoxorany("GameSettings"),nssoxorany("get_SupportedBoth60FPS_CameraHeight"),0);
		// AntiBan
		Antiban[0] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LFrameSynchr"),nssoxorany("UpdateFrameLater"), 0);
		Antiban[1] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LFramework"),nssoxorany("get_SynchrReport"), 0);
		Antiban[2] = get_offset(nssoxorany("System.dll"),nssoxorany("System.Net"),nssoxorany("WebProxy"),nssoxorany("AreAllBypassed"), 2);
		Antiban[3] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LDedicatedSvrConnector"),nssoxorany("SetLogin"), 2);
		Antiban[4] = get_offset(nssoxorany("AovTdr.dll"),nssoxorany("CSProtocol"),nssoxorany("CSDT_CHEATCMD_DETAIL"),nssoxorany("get_stCheatPushMsgToFirebase"), 0);
		Antiban[5] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("CGCloudUpdateSystem"),nssoxorany("get_IsAutoLogin"), 0);
		Antiban[6] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("GCloud.AnoSDK"),nssoxorany("AnoSDK"),nssoxorany("SetUserInfo"), 2);
		Antiban[7] = get_offset(nssoxorany("Project_d.dll"),nssoxorany("Assets.Scripts.GameSystem"),nssoxorany("TssdkSys"),nssoxorany("setUserInfo"), 0);
         /*
		Antiban[8] = oxoranyoffset("0x8c4a0") ;
		Antiban[9] = oxoranyoffset("0x9c4d0") ;
		Antiban[10] = oxoranyoffset("0x9c654") ;
		Antiban[11] = oxoranyoffset("0xc2b0c");
		Antiban[12] = oxoranyoffset("0xc2ee0");
		*/
		Antiban[14] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LSynchrReport"),nssoxorany("EnqueHashValueByFrameNum"), 2);
		Antiban[15] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LSynchrReport"),nssoxorany("SampleFrameSyncData"), 0);
		Antiban[16] = get_offset(nssoxorany("Project.Plugins_d.dll"),nssoxorany("NucleusDrive.Logic"),nssoxorany("LFramework"),nssoxorany("EndGame"), 2);
	}	
	
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
		espManager = new ESPManager();
		SkillSlotManager = new ESPManager();
		ActorLinker_enemy = new ESPManager();
		Flo_Enemy = new ESPManager();
		Flo_Hoa = new ESPManager();
		CbeHook(offset[0],_SetVisible,SetVisible); // hackmap
		CbeHook(offset[4], _GetCameraHeightRateValue, GetCameraHeightRateValue); // cam slider
		CbeHook(offset[5], _Update, Update); // cam slider
		CbeHook(offset[15], _GEE, GEE);
		CbeHook(offset[17], SendSyncData, old_SendSyncData);

		CbeHook(offset[20], _SendInBattleMsg_InputChat,SendInBattleMsg_InputChat); 
		CbeHook(offset[18], RemoveSpace, _RemoveSpace);
		CbeHook(offset[3], _ret, ret); // hide uid
		

		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		//ESP
		CbeHook(ESP[1], _ActorLinker_Update, ActorLinker_Update);  
		CbeHook(ESP[10], _ActorLinker_ActorDestroy, ActorLinker_ActorDestroy);
		CbeHook(ESP[25], _LActorRoot_UpdateLogic, LActorRoot_UpdateLogic);
		CbeHook(ESP[26], _LActorRoot_ActorDestroy, LActorRoot_ActorDestroy);
		CbeHook(ESP[32], _SetPlayerName, SetPlayerName); // change name
		CbeHook(ESP[33], _HostSetPlayerName, HostSetPlayerName); // change name
      	CbeHook(ESP[49], _SkillSlot2_UpdateLogic, SkillSlot2_UpdateLogic);

		});

		ActorLinker_IsHostPlayer = (bool (*)(void *))getRealOffset(ESP[2]);     
		ActorLinker_IsHostCamp = (bool (*)(void *))getRealOffset(ESP[3]);  
		ActorLinker_ActorTypeDef = (int (*)(void *))getRealOffset(ESP[4]);    
		ActorLinker_COM_PLAYERCAMP = (int (*)(void *))getRealOffset(ESP[5]); 
		ActorLinker_getPosition = (Vector3(*)(void *))getRealOffset(ESP[6]);
		ActorLinker_get_ObjID = (int (*)(void *))getRealOffset(ESP[8]); 
		ActorLinker_get_bVisible = (bool (*)(void *))getRealOffset(ESP[9]);
		AsHero = (void*(*)(void*))getRealOffset(ESP[13]);
		LActorRoot_get_forward = (VInt3(*)(void *))getRealOffset(ESP[15]);
		LActorRoot_get_location = (VInt3(*)(void *))getRealOffset(ESP[16]); 
		LActorRoot_LHeroWrapper = (uintptr_t(*)(void *))getRealOffset(ESP[17]);
		LActorRoot_COM_PLAYERCAMP = (int (*)(void *))getRealOffset(ESP[18]); 
		LActorRoot_get_bActive = (bool (*)(void *))getRealOffset(ESP[19]); 
		LActorRoot_get_ObjID = (int (*)(void *))getRealOffset(ESP[20]);
		LObjWrapper_get_IsDeadState = (bool (*)(void *))getRealOffset(ESP[21]); 
		LObjWrapper_IsAutoAI = (bool (*)(void *))getRealOffset(ESP[22]);
		ValuePropertyComponent_get_actorHp = (int (*)(void *))getRealOffset(ESP[23]);    
		ValuePropertyComponent_get_actorHpTotal = (int (*)(void *))getRealOffset(ESP[24]); 
		LEquipComponent_BuyEquip = (void (*)(void*,int,bool,bool))getRealOffset(ESP[43]);
		LEquipComponent_SellEquip = (void (*)(void*,int))getRealOffset(ESP[44]);
		LEquipComponent_GetEquips = (Array<void*> *(*)(void*))getRealOffset(ESP[46]);
		LEquipComponent_UpdateEquipEffect = (void (*)(void*))getRealOffset(ESP[47]);
		ActorLinker_get_playerId = (int (*)(void *))getRealOffset(ESP[48]);
      
		get_CurSkillCD = (void* (*)(void*))getRealOffset(ESP[51]);
		ValuePropertyComponent_get_actorSoulLevel = (int (*)(void *))getRealOffset(ESP[52]); 
		ValuePropertyComponent_get_actorEp = (int (*)(void *))getRealOffset(ESP[53]);    
		ValuePropertyComponent_get_actorEpTotal = (int (*)(void *))getRealOffset(ESP[54]); 
		GetSkillSlot = (void* (*)(void*,int))getRealOffset(ESP[55]);
		get_RealSkillObj = (void* (*)(void*))getRealOffset(ESP[56]);
		get_EquipPassiveSkillInfoMap = (Dictionary<int,void*> *(*)(void*))getRealOffset(ESP[60]);

		GetExistEquipInfoSet = (void* (*)(void*))getRealOffset(ESP[62]);
		GetCurrentActiveEquipId = (int (*)(void*))getRealOffset(ESP[64]);

		GetEquipActiveSkillCD = (int (*)(void*,int))getRealOffset(ESP[69]);
		GetEquipInfo = (void* (*)(void*,int))getRealOffset(ESP[70]);


		get_actorManager = (void* *(*)())getRealOffset(ESP[82]);
		GetAllMonsters = (monoList<void**> *(*)(void*))getRealOffset(ESP[83]);
		ValueLinkerComponent_get_actorSoulLevel = (int (*)(void*))getRealOffset(ESP[84]);

		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		//unlock skin
		CbeHook(ModSkin[0], _IsHaveHeroSkin, IsHaveHeroSkin);
		CbeHook(ModSkin[1], _CanUseSkin, CanUseSkin);
		CbeHook(ModSkin[2], _GetHeroWearSkinId, GetHeroWearSkinId);
		CbeHook(ModSkin[3], _IsPrimeFreeSkin, IsPrimeFreeSkin);
		CbeHook(ModSkin[4], _OnClickSelectHeroSkin, OnClickSelectHeroSkin);
		CbeHook(ModSkin[6], _unpack, unpack);

		});

		RefreshHeroPanel = (void (*)(void*,bool,bool,bool))getRealOffset(ModSkin[5]);
		//Minimap
		
		get_CurMapType = (int (*)(void *))getRealOffset(Minimap[0]);
		get_mmFinalScreenSize = (Vector2 (*)(void *))getRealOffset(Minimap[1]);
		get_bmFinalScreenSize = (Vector2 (*)(void *))getRealOffset(Minimap[2]);
		GetMMFianlScreenPos = (Vector2 (*)(void *))getRealOffset(Minimap[3]);
		GetBMFianlScreenPos = (Vector2 (*)(void *))getRealOffset(Minimap[4]);
		Is3V3Minimap = (bool (*)(void *))getRealOffset(Minimap[6]);
		IsNormal5v5mode = (bool (*)(void *))getRealOffset(Minimap[7]);
		GetGameRoomType = (int (*)(void *))getRealOffset(Minimap[10]);
		
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		// Aim and Bo tro
		CbeHook(AimAndBT[0], _updatelogic, updatelogic);
		CbeHook(AimAndBT[4], _GetUseSkillDirection, GetUseSkillDirection);
		CbeHook(AimAndBT[7], _Skill_lateUpdate, Skill_lateUpdate);
		CbeHook(Minimap[5], _Update_Minimap, Update_Minimap);
		CbeHook(Minimap[8], _get_bMiniMapBgFlip, get_bMiniMapBgFlip);
		CbeHook(AimAndBT[15], _SendMoveDirection, SendMoveDirection);

		});

		CanRequestSkill = (bool (*)(void*,int))getRealOffset(AimAndBT[1]);
		GetCurSkillSlotType = (int (*)(void*))getRealOffset(AimAndBT[2]);
		RequestUseSkillSlot = (bool (*)(void*,int, int, uint, int))getRealOffset(AimAndBT[3]);
		ValueLinkerComponent_get_actorEp = (int (*)(void *))getRealOffset(AimAndBT[10]);
		ValueLinkerComponent_get_actorEpTotal = (int (*)(void *))getRealOffset(AimAndBT[11]);
		LActorRoot_get_PlayerMovement = (void* (*)(void*))getRealOffset(AimAndBT[12]);
		get_speed = (int (*)(void*))getRealOffset(AimAndBT[13]);
		ReadyUseSkillSlot = (void (*)(void*,int,bool))getRealOffset(AimAndBT[14]);
		Reqskill = (bool (*)(void *))getRealOffset(AimAndBT[16]);
		Reqskill2 = (bool (*)(void *,bool))getRealOffset(AimAndBT[17]);
      	StopInput = (void (*)(void*))getRealOffset(AimAndBT[18]);
		//patch offset
		/*
		initPatch();
		uint64_t giatri =  _dyld_get_image_vmaddr_slide(0);
    	saveToFile(uint64ToHex(giatri));
		MemoryFileInfo FileInfo =  getBaseInfo();
		saveToFile(FileInfo.toString());
		*/
    });
    if(loadoff == true)
	{

		for (auto& patch : patch_infos) {
			if (*(patch.setting)) {
				if (!patch.isPatched ) { 
					ActiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework",patch.address, patch.buffer);
					//StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework",patch.address, patch.buffer);
					patch.isPatched = true;
				} 
			}
			else {
				
				if (patch.isPatched) {
					DeactiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework",patch.address, patch.buffer);
					patch.isPatched = false;
				}
			}
		}
	}
}

#endif // HANDLE_H
